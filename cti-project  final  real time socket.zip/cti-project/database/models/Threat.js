import mongoose from "mongoose";

const threatSchema = new mongoose.Schema(
  {
    cve: { type: String, default: "—" },
    title: { type: String, required: true },
    source: { type: String, required: true },
    severity: { type: String, enum: ["Critical", "High", "Medium", "Low"], required: true },
    severityScore: { type: Number, min: 0, max: 100 }, // Output of Algorithm 3 (Multi-Factor Severity Scoring)
    malware: { type: String, default: "—" },
    summary: String,
    description: String,
    affected: String,
    mitigation: String,
    mitre: [String],
    iocs: {
      ips: [String],
      hashes: [String],
      domains: [String],
    },
    articles: [{ title: String, source: String }],
    // Dedup key used by the fetcher's upsert logic (Algorithm 2's UpsertIndicators fingerprint concept)
    fingerprint: { type: String, unique: true, sparse: true },
    isIndiaRelated: { type: Boolean, default: false }, // set via GeoIP lookup, see backend/services/geoip.js
  },
  { timestamps: true }
);

export default mongoose.model("Threat", threatSchema);
