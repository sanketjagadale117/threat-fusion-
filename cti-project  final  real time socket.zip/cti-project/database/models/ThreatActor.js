import mongoose from "mongoose";

const actorSchema = new mongoose.Schema({
  name: { type: String, required: true },
  aliases: [String],
  malware: [String],
  ttps: [String],
});

export default mongoose.model("ThreatActor", actorSchema);
