import mongoose from "mongoose";

// Stores individual IOCs at scale (thousands of rows from list-style feeds
// like Spamhaus/Blocklist.de), separate from the human-readable "Threat"
// summary cards shown on the dashboard. This is what the batch-upsert
// (500 records/commit) actually writes to.
const rawIndicatorSchema = new mongoose.Schema({
  type: { type: String, enum: ["IP", "Domain", "Hash", "URL", "Default"], required: true },
  value: { type: String, required: true },
  source: { type: String, required: true },
  tags: [String],
  fingerprint: { type: String, required: true, unique: true },
  lastSeen: { type: Date, default: Date.now },
  isIndiaRelated: { type: Boolean, default: false }, // set via GeoIP lookup, see backend/services/geoip.js
});

export default mongoose.model("RawIndicator", rawIndicatorSchema);
