import mongoose from "mongoose";

// Caches IP -> country lookups so we never look up the same IP twice.
// Same idea as Algorithm 1's file-hash cache, applied here to avoid
// re-hitting the free GeoIP service (which is rate-limited).
const geoCacheSchema = new mongoose.Schema({
  ip: { type: String, required: true, unique: true },
  country: String,
  countryCode: String,
  city: String,
  checkedAt: { type: Date, default: Date.now },
});

export default mongoose.model("GeoCache", geoCacheSchema);
