import mongoose from "mongoose";

const alertSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    channel: { type: String, required: true },
    severity: { type: String, enum: ["Critical", "High", "Medium", "Low"], required: true },
    threat: { type: mongoose.Schema.Types.ObjectId, ref: "Threat" },
  },
  { timestamps: true }
);

export default mongoose.model("Alert", alertSchema);
