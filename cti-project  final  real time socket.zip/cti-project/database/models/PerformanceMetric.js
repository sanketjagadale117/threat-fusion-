import mongoose from "mongoose";

// Backs the Performance Metrics system (MetricTimer class + /api/metrics/* endpoints)
const metricSchema = new mongoose.Schema(
  {
    metricType: { type: String, enum: ["ingestion", "normalization", "scoring"], required: true },
    operation: { type: String, required: true },
    source: { type: String, default: null },
    itemsProcessed: { type: Number, default: 0 },
    itemsSucceeded: { type: Number, default: 0 },
    itemsFailed: { type: Number, default: 0 },
    durationMs: Number,
    avgTimeMs: Number,
    throughputPerSecond: Number,
  },
  { timestamps: true }
);

export default mongoose.model("PerformanceMetric", metricSchema);
