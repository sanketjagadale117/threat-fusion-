import mongoose from "mongoose";

// Supports Algorithm 1 (hash-based skip of unchanged data) and
// Algorithm 2 (TTL check before re-fetching a source).
const trackingSchema = new mongoose.Schema({
  sourceKey: { type: String, required: true, unique: true },
  lastFetchAt: Date,
  lastStatus: { type: String, enum: ["success", "failed", "skipped"], default: "skipped" },
  lastContentHash: String,
  lastError: String,
  lastItemsUpserted: Number,
});

export default mongoose.model("FetchTracking", trackingSchema);
