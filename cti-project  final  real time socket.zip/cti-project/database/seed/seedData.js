export const threatsSeed = [
  {
    cve: "CVE-2026-12345",
    title: "Critical Microsoft Exchange vulnerability",
    source: "CISA",
    severity: "Critical",
    malware: "BlackBasta",
    summary: "Remote code execution possible. Exploited in the wild. Patch immediately.",
    description:
      "A critical vulnerability in Microsoft Exchange Server allows unauthenticated remote code execution via a crafted request to the autodiscover endpoint. Active exploitation observed by BlackBasta, chained with PowerShell persistence to deploy encryptors.",
    affected: "Microsoft Exchange Server 2019, 2016 (prior to CU14)",
    mitigation:
      "Apply the vendor cumulative update immediately. If delayed, disable the autodiscover endpoint at the reverse proxy and monitor for anomalous PowerShell activity.",
    mitre: ["T1190", "T1059.001"],
    iocs: { ips: ["185.220.101.4"], hashes: ["8f14e45fceea167a"], domains: ["exchange-update[.]net"] },
    articles: [{ title: "CISA advisory AA26-034A", source: "cisa.gov" }],
  },
  {
    cve: "CVE-2026-04471",
    title: "LockBit variant using PowerShell persistence",
    source: "VirusTotal",
    severity: "Critical",
    malware: "LockBit",
    summary: "Targets healthcare sector. CVSS 9.8. Active exploitation confirmed.",
    description:
      "A new LockBit variant establishes persistence through scheduled PowerShell tasks and disables Windows Defender before encrypting files. Primarily targets healthcare orgs with unpatched VPN gateways.",
    affected: "Unpatched VPN gateways, Windows Server 2016+",
    mitigation:
      "Patch VPN gateway firmware, enforce MFA on VPN logins, restrict PowerShell execution policy on servers handling patient data.",
    mitre: ["T1547.001", "T1486"],
    iocs: { ips: ["45.9.148.22"], hashes: ["c4ca4238a0b92382"], domains: [] },
    articles: [{ title: "LockBit healthcare targeting surge", source: "HackerNews" }],
  },
  {
    cve: "CVE-2026-08812",
    title: "New botnet C2 cluster flagged",
    source: "AbuseIPDB",
    severity: "High",
    malware: "Emotet",
    summary: "IPs linked to spam distribution and credential-theft campaigns.",
    description:
      "A cluster of IPs flagged as C2 infrastructure for a resurgent Emotet campaign, distributing malicious macro documents via phishing email.",
    affected: "Any org allowing macro-enabled Office documents via email",
    mitigation: "Block listed IOC domains/IPs at the firewall, disable macros by default, enforce email attachment sandboxing.",
    mitre: ["T1071.001"],
    iocs: { ips: ["103.55.61.12", "103.55.61.13"], hashes: [], domains: ["c2-relay[.]xyz"] },
    articles: [{ title: "AbuseIPDB community report", source: "abuseipdb.com" }],
  },
  {
    cve: "—",
    title: "Zero-day reported in popular VPN client",
    source: "NVD",
    severity: "High",
    malware: "—",
    summary: "Vendor has not issued a patch yet. Workaround available.",
    description:
      "A zero-day allowing session hijacking has been reported in a widely-used VPN client. No official patch yet; vendor has acknowledged the report.",
    affected: "VPN client versions prior to the pending advisory",
    mitigation: "Apply the vendor's interim workaround (disable split tunneling) until patched. Monitor vendor advisories closely.",
    mitre: ["T1210"],
    iocs: { ips: [], hashes: [], domains: [] },
    articles: [{ title: "NVD entry pending analysis", source: "nvd.nist.gov" }],
  },
  {
    cve: "—",
    title: "Phishing kit targeting banking credentials",
    source: "HackerNews",
    severity: "Medium",
    malware: "Generic phishing",
    summary: "Fake login pages mimicking major banks, distributed via SMS.",
    description:
      "A phishing-as-a-service kit distributed via SMS directs victims to convincing fake banking pages that harvest credentials and OTP codes in real time.",
    affected: "End users of major retail banks",
    mitigation: "User awareness training, SMS filtering at carrier level, hardware-key 2FA where possible.",
    mitre: ["T1566.002"],
    iocs: { ips: [], hashes: [], domains: ["secure-bank-login[.]com"] },
    articles: [{ title: "Smishing kit teardown", source: "HackerNews" }],
  },
  {
    cve: "CVE-2025-99881",
    title: "Info disclosure in outdated CMS plugin",
    source: "NVD",
    severity: "Low",
    malware: "—",
    summary: "Requires local access. Limited real-world impact.",
    description:
      "An outdated CMS plugin exposes internal configuration values through a debug endpoint left enabled in production. Requires authenticated local access to exploit.",
    affected: "CMS plugin v2.x, prior to 2.4.1",
    mitigation: "Update to v2.4.1 or disable the debug endpoint in production configuration.",
    mitre: ["T1592"],
    iocs: { ips: [], hashes: [], domains: [] },
    articles: [{ title: "Plugin advisory", source: "NVD" }],
  },
  {
    cve: "CVE-2026-01199",
    title: "WannaCry-linked worm activity resurfacing",
    source: "MalwareBazaar",
    severity: "High",
    malware: "WannaCry",
    summary: "Old SMB exploit still being scanned for at scale.",
    description:
      "Telemetry shows renewed scanning for the SMBv1 vulnerability historically exploited by WannaCry, likely from a botnet building an exploitation list of unpatched legacy systems.",
    affected: "Unpatched Windows systems with SMBv1 enabled",
    mitigation: "Disable SMBv1 network-wide, ensure MS17-010 patch is applied, segment legacy systems from the internet.",
    mitre: ["T1210"],
    iocs: { ips: ["91.203.5.60"], hashes: [], domains: [] },
    articles: [{ title: "Legacy SMB scanning uptick", source: "MalwareBazaar" }],
  },
  {
    cve: "—",
    title: "Supply-chain compromise in npm package",
    source: "HackerNews",
    severity: "Critical",
    malware: "—",
    summary: "Malicious code injected into a popular open-source package.",
    description:
      "A maintainer account compromise led to malicious code being pushed to a widely-used npm package, exfiltrating environment variables from CI pipelines that installed the tainted version.",
    affected: "Projects that installed the compromised version before it was pulled",
    mitigation:
      "Pin dependency versions, audit CI secrets exposure, rotate any credentials that may have been present in affected pipelines.",
    mitre: ["T1195.001"],
    iocs: { ips: [], hashes: [], domains: ["telemetry-collect[.]io"] },
    articles: [{ title: "npm supply-chain incident writeup", source: "HackerNews" }],
  },
];

export const actorsSeed = [
  { name: "BlackBasta", aliases: ["Black Basta"], malware: ["BlackBasta"], ttps: ["T1190", "T1059.001"] },
  { name: "LockBit", aliases: ["LockBit 3.0", "Bitwise Spider"], malware: ["LockBit"], ttps: ["T1547.001", "T1486"] },
  { name: "Emotet operators", aliases: ["Geodo", "Mealybug"], malware: ["Emotet"], ttps: ["T1071.001"] },
  { name: "Unattributed (WannaCry-linked)", aliases: ["—"], malware: ["WannaCry"], ttps: ["T1210"] },
];

// Static reference catalog of MITRE tactics/techniques used to render the MITRE map page.
// The backend marks which of these are "active" based on what's actually in the Threat collection.
export const mitreCatalog = [
  { tactic: "Initial Access", techniques: [{ id: "T1190", name: "Exploit public-facing app" }, { id: "T1566.002", name: "Spearphishing link" }, { id: "T1195.001", name: "Compromise software dependencies" }] },
  { tactic: "Execution", techniques: [{ id: "T1059.001", name: "PowerShell" }] },
  { tactic: "Persistence", techniques: [{ id: "T1547.001", name: "Registry run keys" }] },
  { tactic: "Command & Control", techniques: [{ id: "T1071.001", name: "Web protocols" }] },
  { tactic: "Lateral Movement", techniques: [{ id: "T1210", name: "Exploit remote services" }] },
  { tactic: "Impact", techniques: [{ id: "T1486", name: "Data encrypted for impact" }] },
  { tactic: "Reconnaissance", techniques: [{ id: "T1592", name: "Gather victim host info" }] },
];

// Illustrative weekly trend (until you wire up real historical aggregation from createdAt timestamps)
export const weeklyTrendSeed = [
  { day: "Mon", count: 14 }, { day: "Tue", count: 22 }, { day: "Wed", count: 18 },
  { day: "Thu", count: 30 }, { day: "Fri", count: 26 }, { day: "Sat", count: 12 }, { day: "Sun", count: 8 },
];
