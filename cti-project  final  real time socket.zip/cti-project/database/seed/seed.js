import "dotenv/config";
import { connectDB } from "../db.js";
import Threat from "../models/Threat.js";
import ThreatActor from "../models/ThreatActor.js";
import Alert from "../models/Alert.js";
import FetchTracking from "../models/FetchTracking.js";
import { threatsSeed, actorsSeed } from "./seedData.js";
import { calculateSeverityScore } from "../../backend/services/scoring.js";

async function run() {
  await connectDB();

  console.log("Clearing existing data...");
  await Promise.all([Threat.deleteMany({}), ThreatActor.deleteMany({}), Alert.deleteMany({}), FetchTracking.deleteMany({})]);

  console.log("Scoring + inserting threats...");
  const scoredThreats = threatsSeed.map((t) => {
    const score = calculateSeverityScore({
      source: t.source,
      type: t.cve !== "—" ? "CVE" : t.iocs?.hashes?.length ? "Hash" : t.iocs?.domains?.length ? "Domain" : t.iocs?.ips?.length ? "IP" : "Default",
      description: `${t.description} ${t.summary}`,
      tags: t.mitre || [],
      observationCount: 1,
    });
    return { ...t, severityScore: score, fingerprint: `${t.cve}:${t.title}` };
  });
  const insertedThreats = await Threat.insertMany(scoredThreats);

  console.log("Inserting threat actors...");
  await ThreatActor.insertMany(actorsSeed);

  console.log("Inserting alerts (linked to threats)...");
  const byCve = (cve) => insertedThreats.find((t) => t.cve === cve);
  const byTitleContains = (fragment) => insertedThreats.find((t) => t.title.includes(fragment));

  const alertsSeed = [
    { title: "Critical Exchange RCE — patch now", channel: "Email", severity: "Critical", threat: byCve("CVE-2026-12345")?._id },
    { title: "LockBit healthcare targeting", channel: "Slack", severity: "Critical", threat: byCve("CVE-2026-04471")?._id },
    { title: "npm supply-chain compromise detected", channel: "Telegram", severity: "Critical", threat: byTitleContains("npm")?._id },
    { title: "Botnet C2 cluster — Emotet", channel: "Email", severity: "High", threat: byCve("CVE-2026-08812")?._id },
    { title: "VPN zero-day disclosed", channel: "Slack", severity: "High", threat: byTitleContains("VPN")?._id },
  ];
  await Alert.insertMany(alertsSeed);

  console.log(`Done. Seeded ${insertedThreats.length} threats, ${actorsSeed.length} actors, ${alertsSeed.length} alerts.`);
  process.exit(0);
}

run().catch((err) => {
  console.error("Seeding failed:", err.message);
  process.exit(1);
});
