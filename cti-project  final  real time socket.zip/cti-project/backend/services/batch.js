/**
 * Generic batch upsert helper.
 *
 * Mirrors the UpsertIndicators procedure from Algorithm 2 of the DeltaTI
 * paper (Gad et al., 2026 IEEE 3SCEA), lines 34-45: records are batched
 * into groups (default 500) and each batch is committed as a single bulk
 * write, instead of one round-trip per record. This avoids per-document
 * locking overhead when a single feed can contain thousands of indicators.
 */
export async function batchUpsert(Model, docs, filterFn, batchSize = 500) {
  let batch = [];
  let totalUpserted = 0;
  let batchesCommitted = 0;

  for (const doc of docs) {
    batch.push({ updateOne: { filter: filterFn(doc), update: { $set: doc }, upsert: true } });
    if (batch.length >= batchSize) {
      await Model.bulkWrite(batch, { ordered: false });
      totalUpserted += batch.length;
      batchesCommitted += 1;
      batch = [];
    }
  }

  if (batch.length > 0) {
    await Model.bulkWrite(batch, { ordered: false });
    totalUpserted += batch.length;
    batchesCommitted += 1;
  }

  return { totalUpserted, batchesCommitted, batchSize };
}
