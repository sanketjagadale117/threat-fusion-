import { Server } from "socket.io";

/**
 * Genuine real-time layer using Socket.io (WebSocket, with automatic
 * fallback to HTTP long-polling if a network blocks WebSockets).
 *
 * This is different from the 30-second frontend auto-refresh added earlier
 * (which polls our own database on a timer). This module lets the BACKEND
 * push an event to every connected browser the instant something happens —
 * a new critical threat scored, a source finishing its fetch cycle, the
 * scheduler starting a run — with no polling delay at all.
 */

let ioInstance = null;

export function initRealtime(httpServer) {
  ioInstance = new Server(httpServer, {
    cors: { origin: "*" },
  });

  ioInstance.on("connection", (socket) => {
    console.log(`[realtime] client connected: ${socket.id}`);
    socket.on("disconnect", () => {
      console.log(`[realtime] client disconnected: ${socket.id}`);
    });
  });

  return ioInstance;
}

/**
 * Broadcasts an event to every connected client. Safe to call even if no
 * client is connected yet, or if realtime hasn't been initialized (e.g. in
 * a script run outside the main server process) — it just no-ops.
 */
export function emitEvent(eventName, payload) {
  if (!ioInstance) return;
  ioInstance.emit(eventName, payload);
}
