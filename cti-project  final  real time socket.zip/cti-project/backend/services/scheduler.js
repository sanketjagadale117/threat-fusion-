import cron from "node-cron";
import { runAllFetchers } from "./fetcher.js";

// Matches the paper's "querying sources every 15 minutes" (Section IV-A).
// Runs automatically once the backend starts — no button needed for this
// to happen; the manual "Run live ingestion" button in the UI is in
// addition to this, useful for demos so you don't have to wait 15 minutes.
export function startScheduler() {
  console.log("Scheduler active: all sources will be checked automatically every 15 minutes.");
  cron.schedule("*/15 * * * *", async () => {
    console.log(`[${new Date().toISOString()}] Auto-triggered ingestion cycle starting...`);
    try {
      const results = await runAllFetchers();
      console.log("Auto ingestion cycle complete:", results.map((r) => `${r.source}:${r.status}`).join(", "));
    } catch (err) {
      console.error("Auto ingestion cycle failed:", err.message);
    }
  });
}
