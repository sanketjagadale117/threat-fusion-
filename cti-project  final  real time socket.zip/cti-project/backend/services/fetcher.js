import crypto from "crypto";
import Threat from "../../database/models/Threat.js";
import RawIndicator from "../../database/models/RawIndicator.js";
import FetchTracking from "../../database/models/FetchTracking.js";
import { calculateSeverityScore, scoreToSeverityLabel } from "./scoring.js";
import { batchUpsert } from "./batch.js";
import { MetricTimer } from "./metrics.js";
import { tagIndianIPs } from "./geoip.js";
import { emitEvent } from "./realtime.js";

/**
 * Ingestion engine combining three techniques adapted from:
 * DeltaTI: Threat Intelligence Aggregation Platform, Gad et al., 2026 IEEE 3SCEA
 *
 * - Algorithm 1 (Event-Driven Incremental Normalization): content-hash
 *   comparison skips reprocessing a source whose data hasn't changed, and
 *   a polymorphic parser dispatches on format (JSON / CSV / unstructured
 *   text with regex extraction) — see PARSERS below.
 * - Algorithm 2 (Resilient Multi-Source Fetching): TTL check before
 *   re-fetching, exponential backoff retry (2s/4s/8s) on network failure,
 *   and batched upserts (batchUpsert, 500 records/commit).
 * - Section IX (Performance Metrics): every stage is timed via MetricTimer
 *   and persisted for the /api/metrics/* endpoints.
 */

const MAX_RETRIES = 3;
const FIFTEEN_MIN = 15 * 60 * 1000;
const MAX_ITEMS_PER_LIST_SOURCE = 300; // demo-scale cap; raise for a real deployment

// ---------------------------------------------------------------------------
// Generic parsing helpers (Algorithm 1's polymorphic parser, Lines 9-17)
// ---------------------------------------------------------------------------

function parseCsvLine(line) {
  const result = [];
  let cur = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '"') inQuotes = !inQuotes;
    else if (c === "," && !inQuotes) {
      result.push(cur);
      cur = "";
    } else cur += c;
  }
  result.push(cur);
  return result.map((s) => s.trim());
}

function parseGenericCsv(raw, maxRows = MAX_ITEMS_PER_LIST_SOURCE) {
  return raw
    .split("\n")
    .filter((l) => l && !l.startsWith("#"))
    .slice(0, maxRows)
    .map(parseCsvLine);
}

const IPV4_REGEX = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;

function extractIPv4List(raw, maxItems = MAX_ITEMS_PER_LIST_SOURCE) {
  const ips = new Set();
  for (const line of raw.split("\n")) {
    if (!line || line.startsWith("#") || line.startsWith(";")) continue;
    const match = line.match(IPV4_REGEX);
    if (match) ips.add(match[0]);
    if (ips.size >= maxItems) break;
  }
  return [...ips].map((ip) => ({ type: "IP", value: ip, tags: [] }));
}

function mapIocType(raw) {
  const t = (raw || "").toLowerCase();
  if (t.includes("ip")) return "IP";
  if (t.includes("url")) return "URL";
  if (t.includes("domain") || t.includes("host")) return "Domain";
  if (t.includes("hash") || t.includes("md5") || t.includes("sha")) return "Hash";
  return "Default";
}

function sha256(str) {
  return crypto.createHash("sha256").update(str).digest("hex");
}

// ---------------------------------------------------------------------------
// "report" sources — each item becomes its own Threat document directly
// (structured, high-context feeds: vulnerabilities and curated pulses)
// ---------------------------------------------------------------------------

function normalizeCisaKev(raw) {
  const data = JSON.parse(raw);
  return (data.vulnerabilities || []).slice(0, 8).map((v) => ({
    cve: v.cveID,
    title: v.vulnerabilityName,
    source: "CISA",
    malware: "—",
    summary: (v.shortDescription || "Actively exploited vulnerability per CISA KEV catalog.").slice(0, 220),
    description: v.shortDescription || "",
    affected: `${v.vendorProject || ""} ${v.product || ""}`.trim(),
    mitigation: v.requiredAction || "Apply the vendor patch per CISA guidance.",
    mitre: [],
    iocs: { ips: [], hashes: [], domains: [] },
    articles: [{ title: "CISA KEV Catalog entry", source: "cisa.gov" }],
    _type: "CVE",
    _tags: ["known-exploited"],
  }));
}

function normalizeNvd(raw) {
  const data = JSON.parse(raw);
  return (data.vulnerabilities || []).slice(0, 8).map((item) => {
    const cve = item.cve;
    const desc = cve.descriptions?.find((d) => d.lang === "en")?.value || "";
    const metrics = cve.metrics?.cvssMetricV31?.[0] || cve.metrics?.cvssMetricV30?.[0];
    const baseSeverity = metrics?.cvssData?.baseSeverity || "";
    return {
      cve: cve.id,
      title: desc.slice(0, 90) || cve.id,
      source: "NVD",
      malware: "—",
      summary: desc.slice(0, 220),
      description: desc,
      affected: "See NVD entry for affected configurations",
      mitigation: "Review the NVD advisory and apply the vendor patch.",
      mitre: [],
      iocs: { ips: [], hashes: [], domains: [] },
      articles: [{ title: `NVD entry ${cve.id}`, source: "nvd.nist.gov" }],
      _type: "CVE",
      _tags: baseSeverity ? [baseSeverity.toLowerCase()] : [],
    };
  });
}

function normalizeOtx(raw) {
  const data = JSON.parse(raw);
  return (data.results || []).slice(0, 8).map((pulse) => {
    const ips = pulse.indicators?.filter((i) => i.type === "IPv4").map((i) => i.indicator) || [];
    const domains = pulse.indicators?.filter((i) => i.type === "domain" || i.type === "hostname").map((i) => i.indicator) || [];
    const hashes = pulse.indicators?.filter((i) => i.type?.includes("Hash")).map((i) => i.indicator) || [];
    return {
      cve: "—",
      title: pulse.name?.slice(0, 90) || "OTX pulse",
      source: "AlienVault OTX",
      malware: pulse.malware_families?.[0]?.display_name || "—",
      summary: (pulse.description || "Community-reported threat pulse.").slice(0, 220),
      description: pulse.description || "",
      affected: "See pulse for affected scope",
      mitigation: "Cross-reference IOCs against your network logs and block confirmed indicators.",
      mitre: [],
      iocs: { ips, hashes, domains },
      articles: [{ title: pulse.name, source: "otx.alienvault.com" }],
      _type: hashes.length ? "Hash" : domains.length ? "Domain" : ips.length ? "IP" : "Default",
      _tags: pulse.tags || [],
    };
  });
}

// ---------------------------------------------------------------------------
// "iocs" sources — bulk indicator lists (IP blocklists, hash/URL feeds).
// Parsers dispatch by format per Algorithm 1: CSV vs unstructured text.
// ---------------------------------------------------------------------------

const extractFeodoIps = (raw) =>
  parseGenericCsv(raw)
    .map((f) => ({ type: "IP", value: f[1], tags: f[5] ? [f[5]] : [] }))
    .filter((i) => i.value && IPV4_REGEX.test(i.value));

const extractUrlhaus = (raw) =>
  parseGenericCsv(raw)
    .map((f) => ({ type: "URL", value: f[2], tags: (f[6] || "").split(",").filter(Boolean) }))
    .filter((i) => i.value);

const extractThreatFox = (raw) =>
  parseGenericCsv(raw)
    .map((f) => ({ type: mapIocType(f[3]), value: f[2], tags: [f[4], f[5]].filter(Boolean) }))
    .filter((i) => i.value);

const extractMalwareBazaar = (raw) =>
  parseGenericCsv(raw)
    .map((f) => ({ type: "Hash", value: f[1], tags: f[8] ? [f[8]] : [] }))
    .filter((i) => i.value);

const extractSslbl = (raw) =>
  parseGenericCsv(raw)
    .map((f) => ({ type: "Hash", value: f[1], tags: f[2] ? [f[2]] : [] }))
    .filter((i) => i.value);

// ---------------------------------------------------------------------------
// Source configuration — 12 built-in feeds + AlienVault OTX (13th, optional,
// requires a free API key). This mirrors the paper's ">13 feeds" claim while
// staying honest about which one needs extra setup.
// ---------------------------------------------------------------------------

export const REPORT_SOURCES_META = [
  { key: "cisa_kev", name: "CISA", category: "Vulnerabilities", format: "JSON" },
  { key: "nvd_recent", name: "NVD", category: "Vulnerabilities", format: "JSON" },
  { key: "otx_pulses", name: "AlienVault OTX", category: "ThreatIntel", format: "JSON", optional: true },
];

export const IOC_SOURCES_META = [
  { key: "urlhaus", name: "URLhaus", category: "Phishing", format: "CSV" },
  { key: "threatfox", name: "ThreatFox", category: "ThreatIntel", format: "CSV" },
  { key: "malwarebazaar", name: "MalwareBazaar", category: "Malware", format: "CSV" },
  { key: "sslbl", name: "SSL Blacklist", category: "Malware", format: "CSV" },
  { key: "feodo_tracker", name: "Feodo Tracker", category: "IP", format: "CSV" },
  { key: "spamhaus_drop", name: "Spamhaus DROP", category: "IP", format: "Text" },
  { key: "blocklist_de", name: "Blocklist.de", category: "IP", format: "Text" },
  { key: "cins_army", name: "CINS Army List", category: "IP", format: "Text" },
  { key: "dshield", name: "DShield Block List", category: "IP", format: "Text" },
  { key: "emerging_threats", name: "Emerging Threats", category: "IP", format: "Text" },
];

export const ALL_SOURCES_META = [...REPORT_SOURCES_META, ...IOC_SOURCES_META];

function buildSources() {
  const reportSources = [
    { key: "cisa_kev", name: "CISA", kind: "report", ttlMs: FIFTEEN_MIN, url: "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json", headers: {}, parser: normalizeCisaKev },
    { key: "nvd_recent", name: "NVD", kind: "report", ttlMs: FIFTEEN_MIN, url: "https://services.nvd.nist.gov/rest/json/cves/2.0?resultsPerPage=15", headers: process.env.NVD_API_KEY ? { apiKey: process.env.NVD_API_KEY } : {}, parser: normalizeNvd },
  ];
  if (process.env.OTX_API_KEY) {
    reportSources.push({
      key: "otx_pulses", name: "AlienVault OTX", kind: "report", ttlMs: FIFTEEN_MIN,
      url: "https://otx.alienvault.com/api/v1/pulses/subscribed?limit=5",
      headers: { "X-OTX-API-KEY": process.env.OTX_API_KEY }, parser: normalizeOtx,
    });
  }

  const iocSources = [
    { key: "urlhaus", name: "URLhaus", kind: "iocs", ttlMs: FIFTEEN_MIN, url: "https://urlhaus.abuse.ch/downloads/csv_recent/", headers: {}, parser: extractUrlhaus },
    { key: "threatfox", name: "ThreatFox", kind: "iocs", ttlMs: FIFTEEN_MIN, url: "https://threatfox.abuse.ch/export/csv/recent/", headers: {}, parser: extractThreatFox },
    { key: "malwarebazaar", name: "MalwareBazaar", kind: "iocs", ttlMs: FIFTEEN_MIN, url: "https://bazaar.abuse.ch/export/csv/recent/", headers: {}, parser: extractMalwareBazaar },
    { key: "sslbl", name: "SSL Blacklist", kind: "iocs", ttlMs: FIFTEEN_MIN, url: "https://sslbl.abuse.ch/blacklist/sslblacklist.csv", headers: {}, parser: extractSslbl },
    { key: "feodo_tracker", name: "Feodo Tracker", kind: "iocs", ttlMs: FIFTEEN_MIN, url: "https://feodotracker.abuse.ch/downloads/ipblocklist.csv", headers: {}, parser: extractFeodoIps },
    { key: "spamhaus_drop", name: "Spamhaus DROP", kind: "iocs", ttlMs: FIFTEEN_MIN, url: "https://www.spamhaus.org/drop/drop.txt", headers: {}, parser: extractIPv4List },
    { key: "blocklist_de", name: "Blocklist.de", kind: "iocs", ttlMs: FIFTEEN_MIN, url: "https://lists.blocklist.de/lists/all.txt", headers: {}, parser: extractIPv4List },
    { key: "cins_army", name: "CINS Army List", kind: "iocs", ttlMs: FIFTEEN_MIN, url: "http://cinsscore.com/list/ci-badguys.txt", headers: {}, parser: extractIPv4List },
    { key: "dshield", name: "DShield Block List", kind: "iocs", ttlMs: FIFTEEN_MIN, url: "https://www.dshield.org/block.txt", headers: {}, parser: extractIPv4List },
    { key: "emerging_threats", name: "Emerging Threats", kind: "iocs", ttlMs: FIFTEEN_MIN, url: "https://rules.emergingthreats.net/blockrules/compromised-ips.txt", headers: {}, parser: extractIPv4List },
  ];

  return [...reportSources, ...iocSources];
}

// ---------------------------------------------------------------------------
// Core fetch loop
// ---------------------------------------------------------------------------

async function fetchWithBackoff(url, headers) {
  let attempt = 0;
  let lastErr;
  while (attempt < MAX_RETRIES) {
    try {
      const res = await fetch(url, { headers: { "User-Agent": "CTI-Aggregator-Student-Project", ...headers } });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.text();
    } catch (err) {
      lastErr = err;
      attempt++;
      if (attempt >= MAX_RETRIES) break;
      const waitMs = 2 ** attempt * 1000; // 2s, 4s, 8s
      await new Promise((resolve) => setTimeout(resolve, waitMs));
    }
  }
  throw lastErr;
}

export async function runAllFetchers() {
  const results = [];
  const ingestionTimer = new MetricTimer("ingestion", "run_all_fetchers");
  const sources = buildSources();

  emitEvent("ingestion:started", { startedAt: new Date().toISOString(), totalSources: sources.length });

  for (const source of sources) {
    const tracking = await FetchTracking.findOne({ sourceKey: source.key });
    const now = Date.now();

    // Algorithm 2, lines 5-9: skip if TTL hasn't expired
    if (tracking?.lastFetchAt && now - tracking.lastFetchAt.getTime() < source.ttlMs) {
      const entry = { source: source.name, status: "skipped", reason: "TTL not expired" };
      results.push(entry);
      emitEvent("ingestion:source-result", entry);
      continue;
    }

    try {
      // Algorithm 2, lines 13-23: fetch with exponential backoff
      const raw = await fetchWithBackoff(source.url, source.headers);
      const contentHash = sha256(raw);

      // Algorithm 1: skip if content is byte-identical to the last fetch
      if (tracking?.lastContentHash === contentHash) {
        await FetchTracking.updateOne({ sourceKey: source.key }, { lastFetchAt: new Date(), lastStatus: "skipped" }, { upsert: true });
        const entry = { source: source.name, status: "skipped", reason: "content unchanged (hash match)" };
        results.push(entry);
        emitEvent("ingestion:source-result", entry);
        continue;
      }

      let upserted = 0;
      let batchesCommitted = 0;
      const normTimer = new MetricTimer("normalization", `parse_${source.key}`, source.name);

      if (source.kind === "report") {
        const items = source.parser(raw);
        normTimer.recordBatch(items.length);
        await normTimer.finish();

        const scoreTimer = new MetricTimer("scoring", `score_${source.key}`, source.name);
        const scoredDocs = items.map((item) => {
          const score = calculateSeverityScore({
            source: item.source, type: item._type,
            description: `${item.description} ${item.summary}`, tags: item._tags, observationCount: 1,
          });
          scoreTimer.recordItem(true);
          const doc = { ...item, severityScore: score, severity: scoreToSeverityLabel(score), fingerprint: sha256(`${item._type}:${item.cve}:${item.title}`) };
          delete doc._type;
          delete doc._tags;
          return doc;
        });
        await scoreTimer.finish();

        // Check which of these already exist, so we can tell genuinely new
        // threats from re-processed ones — used for the real-time events below.
        const existingFingerprints = new Set(
          (await Threat.find({ fingerprint: { $in: scoredDocs.map((d) => d.fingerprint) } }, { fingerprint: 1 })).map((d) => d.fingerprint)
        );

        const batchResult = await batchUpsert(Threat, scoredDocs, (d) => ({ fingerprint: d.fingerprint }));
        upserted = batchResult.totalUpserted;
        batchesCommitted = batchResult.batchesCommitted;

        for (const doc of scoredDocs) {
          const isNew = !existingFingerprints.has(doc.fingerprint);
          if (isNew) emitEvent("threat:new", { threat: doc });
          if (doc.severity === "Critical") emitEvent("alert:critical", { threat: doc });
        }
      } else {
        // "iocs" source: bulk indicator list -> RawIndicator (batched) + one summary Threat card
        const rawItems = source.parser(raw);
        normTimer.recordBatch(rawItems.length);
        await normTimer.finish();

        // GeoIP-tag the IP indicators to flag which ones resolve to India —
        // our stand-in for "India-specific OSINT", since CERT-In has no public API.
        const ipValues = [...new Set(rawItems.filter((it) => it.type === "IP").map((it) => it.value))];
        const indiaMap = await tagIndianIPs(ipValues);

        const indicatorDocs = rawItems.map((it) => {
          const doc = {
            type: it.type, value: it.value, source: source.name, tags: it.tags || [],
            fingerprint: sha256(`${it.type}:${it.value}`), lastSeen: new Date(),
          };
          if (it.type === "IP" && indiaMap.has(it.value)) {
            doc.isIndiaRelated = indiaMap.get(it.value);
          }
          return doc;
        });

        const batchResult = await batchUpsert(RawIndicator, indicatorDocs, (d) => ({ fingerprint: d.fingerprint }), 500);
        upserted = batchResult.totalUpserted;
        batchesCommitted = batchResult.batchesCommitted;

        if (rawItems.length > 0) {
          const typeCounts = {};
          rawItems.forEach((it) => { typeCounts[it.type] = (typeCounts[it.type] || 0) + 1; });
          const dominantType = Object.entries(typeCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || "IP";

          const scoreTimer = new MetricTimer("scoring", `score_${source.key}`, source.name);
          const score = calculateSeverityScore({
            source: source.name, type: dominantType,
            description: `${source.name} feed update ${source.category || ""}`, tags: [], observationCount: rawItems.length,
          });
          scoreTimer.recordItem(true);
          await scoreTimer.finish();

          const sample = (type) => rawItems.filter((i) => i.type === type).slice(0, 10).map((i) => i.value);
          const indiaCount = [...indiaMap.values()].filter(Boolean).length;
          const summaryDoc = {
            cve: "—",
            title: `${source.name}: ${rawItems.length} new indicators ingested`,
            source: source.name,
            malware: "—",
            summary: `${rawItems.length} indicators (${Object.entries(typeCounts).map(([k, v]) => `${v} ${k}`).join(", ")}) added from ${source.name} in this cycle.${indiaCount > 0 ? ` ${indiaCount} geolocated to India.` : ""}`,
            description: `Automated feed ingestion from ${source.name}. ${rawItems.length} total indicators stored; sample shown below.`,
            affected: "Networks exposed to indicators of this type",
            mitigation: "Block confirmed malicious IPs/domains/hashes at the firewall or EDR.",
            mitre: [],
            iocs: { ips: sample("IP"), domains: [...sample("Domain"), ...sample("URL")], hashes: sample("Hash") },
            articles: [{ title: `${source.name} feed`, source: safeHost(source.url) }],
            severity: scoreToSeverityLabel(score),
            severityScore: score,
            fingerprint: sha256(`feed-summary:${source.key}:${contentHash}`),
          };
          const existingSummary = await Threat.findOne({ fingerprint: summaryDoc.fingerprint }, { _id: 1 });
          await Threat.updateOne({ fingerprint: summaryDoc.fingerprint }, { $set: summaryDoc }, { upsert: true });
          if (!existingSummary) emitEvent("threat:new", { threat: summaryDoc });
          if (summaryDoc.severity === "Critical") emitEvent("alert:critical", { threat: summaryDoc });

          // If any indicators geolocated to India, also create a dedicated
          // India-only Threat card — this is what makes India threats show
          // up as first-class entries in the Dashboard/Feed, not just buried
          // inside the general Indicators table.
          if (indiaCount > 0) {
            const indiaIps = ipValues.filter((ip) => indiaMap.get(ip) === true);
            const indiaScore = calculateSeverityScore({
              source: source.name, type: "IP",
              description: `India-geolocated indicators from ${source.name}`, tags: ["india"], observationCount: indiaCount,
            });
            const indiaDoc = {
              cve: "—",
              title: `${source.name}: ${indiaCount} indicator${indiaCount > 1 ? "s" : ""} geolocated to India`,
              source: source.name,
              malware: "—",
              summary: `${indiaCount} IP indicator${indiaCount > 1 ? "s" : ""} from this feed resolved to an India-based IP address (via GeoIP lookup).`,
              description: `Out of ${rawItems.length} indicators ingested from ${source.name} in this cycle, ${indiaCount} were geolocated to India using a free GeoIP lookup (ip-api.com). This is not India-specific threat intelligence — it is global OSINT data filtered by IP geolocation, since no equivalent CERT-In API exists.`,
              affected: "Networks and infrastructure located in India",
              mitigation: "Cross-reference these IPs against your own network logs; block confirmed malicious ones at the firewall.",
              mitre: [],
              iocs: { ips: indiaIps.slice(0, 10), domains: [], hashes: [] },
              articles: [{ title: `${source.name} feed (India-geolocated subset)`, source: safeHost(source.url) }],
              severity: scoreToSeverityLabel(indiaScore),
              severityScore: indiaScore,
              isIndiaRelated: true,
              fingerprint: sha256(`feed-summary-india:${source.key}:${contentHash}`),
            };
            await Threat.updateOne({ fingerprint: indiaDoc.fingerprint }, { $set: indiaDoc }, { upsert: true });
            emitEvent("threat:india", { threat: indiaDoc });
            if (indiaDoc.severity === "Critical") emitEvent("alert:critical", { threat: indiaDoc, isIndia: true });
          }
        }
      }

      await FetchTracking.updateOne(
        { sourceKey: source.key },
        { lastFetchAt: new Date(), lastStatus: "success", lastContentHash: contentHash, lastItemsUpserted: upserted, lastError: null },
        { upsert: true }
      );
      ingestionTimer.recordItem(true);
      const successEntry = { source: source.name, status: "success", itemsUpserted: upserted, batchesCommitted };
      results.push(successEntry);
      emitEvent("ingestion:source-result", successEntry);
    } catch (err) {
      ingestionTimer.recordItem(false);
      await FetchTracking.updateOne(
        { sourceKey: source.key },
        { lastFetchAt: new Date(), lastStatus: "failed", lastError: err.message },
        { upsert: true }
      );
      const failEntry = { source: source.name, status: "failed", error: err.message };
      results.push(failEntry);
      emitEvent("ingestion:source-result", failEntry);
    }
  }

  await ingestionTimer.finish();
  emitEvent("ingestion:completed", { completedAt: new Date().toISOString(), results });
  return results;
}

function safeHost(url) {
  try {
    return new URL(url).hostname;
  } catch {
    return url;
  }
}
