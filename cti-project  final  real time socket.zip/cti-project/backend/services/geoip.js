import GeoCache from "../../database/models/GeoCache.js";

/**
 * Tags IP indicators as India-related using free GeoIP lookups (ip-api.com,
 * no key required, 45 requests/minute on the free tier).
 *
 * This exists because there is no equivalent to CISA/NVD for India — CERT-In
 * publishes advisories as web pages, not a structured API — so instead of a
 * dedicated India feed, we geolocate the IPs we already collect from the
 * global feeds (URLhaus, Spamhaus, etc.) and flag which ones resolve to India.
 *
 * Every lookup is cached in MongoDB (GeoCache) so a given IP is only ever
 * sent to ip-api.com once, keeping us well under the rate limit on repeat runs.
 */

const RATE_LIMIT_DELAY_MS = 1500; // ~40 req/min, safely under the 45/min free-tier cap

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function lookupIp(ip) {
  try {
    const res = await fetch(`http://ip-api.com/json/${ip}?fields=status,country,countryCode,city`);
    const data = await res.json();
    if (data.status !== "success") return null;

    return GeoCache.findOneAndUpdate(
      { ip },
      { ip, country: data.country, countryCode: data.countryCode, city: data.city, checkedAt: new Date() },
      { upsert: true, new: true }
    );
  } catch (err) {
    return null;
  }
}

/**
 * @param {string} ip
 * @returns {Promise<boolean>} true if this IP resolves to India
 */
export async function isIndianIP(ip) {
  const cached = await GeoCache.findOne({ ip });
  if (cached) return cached.countryCode === "IN";

  const geo = await lookupIp(ip);
  await sleep(RATE_LIMIT_DELAY_MS); // only throttle genuinely new lookups
  return geo?.countryCode === "IN";
}

/**
 * @param {string[]} ips
 * @param {number} maxNewLookups - caps fresh (uncached) network lookups per
 *   call, so one ingestion cycle never blocks for minutes on a large IP list.
 *   IPs beyond the cap are simply left unresolved this cycle (no entry in the
 *   returned map) and will be picked up on a later run once cached IPs free
 *   up the budget, or once the cap is raised.
 * @returns {Promise<Map<string, boolean>>} ip -> isIndiaRelated (only for resolved IPs)
 */
export async function tagIndianIPs(ips, maxNewLookups = 15) {
  const results = new Map();
  let newLookups = 0;

  for (const ip of ips) {
    const cached = await GeoCache.findOne({ ip });
    if (cached) {
      results.set(ip, cached.countryCode === "IN");
      continue;
    }
    if (newLookups >= maxNewLookups) continue; // leave unresolved this cycle

    const geo = await lookupIp(ip);
    results.set(ip, geo?.countryCode === "IN");
    newLookups++;
    await sleep(RATE_LIMIT_DELAY_MS);
  }

  return results;
}
