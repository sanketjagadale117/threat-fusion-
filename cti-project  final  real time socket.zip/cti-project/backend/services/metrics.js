import PerformanceMetric from "../../database/models/PerformanceMetric.js";

/**
 * Performance Metrics system — instruments the ingestion pipeline the way
 * Section IX of the paper describes: a timer class measuring items/second
 * throughput, per-stage latency (ingestion / normalization / scoring), and
 * item success/failure counts, persisted to a dedicated collection and
 * exposed via the /api/metrics/* endpoints.
 */
export class MetricTimer {
  constructor(metricType, operation, source = null) {
    this.metricType = metricType; // "ingestion" | "normalization" | "scoring"
    this.operation = operation; // e.g. "run_all_fetchers", "parse_urlhaus"
    this.source = source; // e.g. "CISA", null for pipeline-wide timers
    this.startTime = Date.now();
    this.itemsProcessed = 0;
    this.itemsSucceeded = 0;
    this.itemsFailed = 0;
  }

  recordItem(success = true) {
    this.itemsProcessed += 1;
    if (success) this.itemsSucceeded += 1;
    else this.itemsFailed += 1;
  }

  recordBatch(succeeded = 0, failed = 0) {
    this.itemsProcessed += succeeded + failed;
    this.itemsSucceeded += succeeded;
    this.itemsFailed += failed;
  }

  async finish() {
    const durationMs = Date.now() - this.startTime;
    const avgTimeMs = this.itemsProcessed ? +(durationMs / this.itemsProcessed).toFixed(4) : 0;
    const throughputPerSecond = durationMs > 0 ? +((this.itemsProcessed / (durationMs / 1000)).toFixed(1)) : 0;

    return PerformanceMetric.create({
      metricType: this.metricType,
      operation: this.operation,
      source: this.source,
      itemsProcessed: this.itemsProcessed,
      itemsSucceeded: this.itemsSucceeded,
      itemsFailed: this.itemsFailed,
      durationMs,
      avgTimeMs,
      throughputPerSecond,
    });
  }
}
