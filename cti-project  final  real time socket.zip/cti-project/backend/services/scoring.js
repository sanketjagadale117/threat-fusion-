/**
 * Multi-Factor Severity Scoring
 * Adapted from: DeltaTI: Threat Intelligence Aggregation Platform
 * Gad et al., 2026 IEEE 3SCEA — Algorithm 3
 *
 * Score = 50 (neutral baseline)
 *       + (SourceReliability - 50) * 0.3
 *       + (TypeSeverity - 50) * 0.3
 *       + keyword boost (+20 critical / +10 high)
 *       + observation frequency boost (ln(count) * 2, capped at 10)
 *       clamped to [0, 100]
 */

// Factor 1: Source reliability (30% weight) — static trust mapping
const RELIABILITY_MAP = {
  CISA: 95,
  NVD: 90,
  "AlienVault OTX": 80,
  VirusTotal: 85,
  AbuseIPDB: 70,
  MalwareBazaar: 80,
  HackerNews: 55,
  Default: 50,
};

// Factor 2: Indicator type severity (30% weight)
const TYPE_MAP = {
  Hash: 80,   // malware hashes = highest confidence of maliciousness
  Domain: 60,
  IP: 55,     // IPs are often dynamic/shared (NAT), lower inherent trust
  CVE: 75,
  Default: 50,
};

// Factor 3: Contextual keyword analysis
const CRITICAL_KEYWORDS = ["ransomware", "apt", "c2", "command and control", "zero-day", "rce", "remote code execution", "supply chain"];
const HIGH_KEYWORDS = ["exploit", "botnet", "trojan", "credential", "phishing", "worm"];

/**
 * @param {Object} ioc
 * @param {string} ioc.source - e.g. "CISA", "NVD"
 * @param {string} ioc.type - "CVE" | "IP" | "Domain" | "Hash" | "Default"
 * @param {string} ioc.description - free text used for keyword scanning
 * @param {string[]} [ioc.tags]
 * @param {number} [ioc.observationCount] - how many independent sources reported this
 * @returns {number} severity score, 0-100
 */
export function calculateSeverityScore({ source, type, description = "", tags = [], observationCount = 1 }) {
  let score = 50; // neutral baseline

  // Factor 1: Source Reliability (30% weight)
  const sVal = RELIABILITY_MAP[source] ?? RELIABILITY_MAP.Default;
  score += (sVal - 50) * 0.3;

  // Factor 2: Type Severity (30% weight)
  const tVal = TYPE_MAP[type] ?? TYPE_MAP.Default;
  score += (tVal - 50) * 0.3;

  // Factor 3: Contextual Analysis (keywords)
  const context = `${description} ${tags.join(" ")}`.toLowerCase();
  if (CRITICAL_KEYWORDS.some((k) => context.includes(k))) {
    score += 20;
  } else if (HIGH_KEYWORDS.some((k) => context.includes(k))) {
    score += 10;
  }

  // Factor 4: Observation Frequency (corroboration across sources)
  if (observationCount > 1) {
    const boost = Math.min(10, Math.log(observationCount) * 2);
    score += boost;
  }

  return clamp(Math.round(score), 0, 100);
}

/**
 * Maps a 0-100 numeric score to a Critical/High/Medium/Low band.
 * Thresholds are our own choice (the paper doesn't fix exact cut points,
 * beyond citing "Cscore > 80" as a "high confidence" example).
 */
export function scoreToSeverityLabel(score) {
  if (score >= 85) return "Critical";
  if (score >= 65) return "High";
  if (score >= 40) return "Medium";
  return "Low";
}

function clamp(n, min, max) {
  return Math.max(min, Math.min(max, n));
}
