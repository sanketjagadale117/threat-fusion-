import { Router } from "express";
import PerformanceMetric from "../../database/models/PerformanceMetric.js";

const router = Router();

// 1. GET /api/metrics — latest raw records
router.get("/", async (req, res) => {
  try {
    const limit = Math.min(Number(req.query.limit) || 50, 500);
    const rows = await PerformanceMetric.find().sort({ createdAt: -1 }).limit(limit);
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// 2. GET /api/metrics/summary — aggregated report per metric type
router.get("/summary", async (req, res) => {
  try {
    const agg = await PerformanceMetric.aggregate([
      { $group: { _id: "$metricType", avgThroughput: { $avg: "$throughputPerSecond" }, totalItems: { $sum: "$itemsProcessed" }, totalSucceeded: { $sum: "$itemsSucceeded" }, totalFailed: { $sum: "$itemsFailed" }, count: { $sum: 1 } } },
    ]);
    res.json(agg);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// 3. GET /api/metrics/by-source — per-source breakdown
router.get("/by-source", async (req, res) => {
  try {
    const agg = await PerformanceMetric.aggregate([
      { $match: { source: { $ne: null } } },
      { $group: { _id: "$source", totalItems: { $sum: "$itemsProcessed" }, avgThroughput: { $avg: "$throughputPerSecond" }, lastRun: { $max: "$createdAt" } } },
      { $sort: { totalItems: -1 } },
    ]);
    res.json(agg);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// 4. GET /api/metrics/by-type/:type — filter by ingestion|normalization|scoring
router.get("/by-type/:type", async (req, res) => {
  try {
    const rows = await PerformanceMetric.find({ metricType: req.params.type }).sort({ createdAt: -1 }).limit(100);
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// 5. GET /api/metrics/trends?hours=24 — historical trend, configurable time range
router.get("/trends", async (req, res) => {
  try {
    const hours = Number(req.query.hours) || 24;
    const since = new Date(Date.now() - hours * 60 * 60 * 1000);
    const agg = await PerformanceMetric.aggregate([
      { $match: { createdAt: { $gte: since } } },
      { $group: {
          _id: { $dateToString: { format: "%Y-%m-%dT%H:00:00", date: "$createdAt" } },
          avgThroughput: { $avg: "$throughputPerSecond" },
          totalItems: { $sum: "$itemsProcessed" },
        } },
      { $sort: { _id: 1 } },
    ]);
    res.json(agg);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// 6. GET /api/metrics/throughput — latest throughput per operation
router.get("/throughput", async (req, res) => {
  try {
    const agg = await PerformanceMetric.aggregate([
      { $sort: { createdAt: -1 } },
      { $group: { _id: "$operation", latestThroughput: { $first: "$throughputPerSecond" }, latestAt: { $first: "$createdAt" } } },
    ]);
    res.json(agg);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// 7. GET /api/metrics/accuracy — stub, honestly labeled (see README)
router.get("/accuracy", async (req, res) => {
  res.json({
    note: "False-positive/false-negative tracking requires labeled ground-truth data, which this student project does not collect. Fields are placeholders for a future extension.",
    truePositives: null, falsePositives: null, trueNegatives: null, falseNegatives: null,
  });
});

// 8. GET /api/metrics/latest — most recent metric per operation
router.get("/latest", async (req, res) => {
  try {
    const agg = await PerformanceMetric.aggregate([
      { $sort: { createdAt: -1 } },
      { $group: { _id: "$operation", latest: { $first: "$$ROOT" } } },
    ]);
    res.json(agg.map((a) => a.latest));
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// 9. GET /api/metrics/count — total + breakdown by type
router.get("/count", async (req, res) => {
  try {
    const total = await PerformanceMetric.countDocuments();
    const byType = await PerformanceMetric.aggregate([{ $group: { _id: "$metricType", count: { $sum: 1 } } }]);
    res.json({ total, byType });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// 10. DELETE /api/metrics — reset (handy for re-running a clean demo)
router.delete("/", async (req, res) => {
  try {
    const result = await PerformanceMetric.deleteMany({});
    res.json({ deleted: result.deletedCount });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

export default router;
