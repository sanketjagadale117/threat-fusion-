import { Router } from "express";
import Threat from "../../database/models/Threat.js";
import { mitreCatalog } from "../../database/seed/seedData.js";

const router = Router();

// GET /api/mitre — returns the full technique catalog + which ones are "active" right now
router.get("/", async (req, res) => {
  try {
    const threats = await Threat.find();
    const active = [...new Set(threats.flatMap((t) => t.mitre))];
    res.json({ catalog: mitreCatalog, active });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
