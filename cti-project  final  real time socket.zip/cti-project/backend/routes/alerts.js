import { Router } from "express";
import Alert from "../../database/models/Alert.js";

const router = Router();

// GET /api/alerts
router.get("/", async (req, res) => {
  try {
    const alerts = await Alert.find().populate("threat").sort({ createdAt: -1 });
    res.json(alerts);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
