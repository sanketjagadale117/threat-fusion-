import { Router } from "express";
import { runAllFetchers, ALL_SOURCES_META } from "../services/fetcher.js";
import FetchTracking from "../../database/models/FetchTracking.js";

const router = Router();

// POST /api/ingest/run — manually trigger all fetchers (Algorithms 1 + 2)
router.post("/run", async (req, res) => {
  try {
    const results = await runAllFetchers();
    res.json({ ranAt: new Date().toISOString(), results });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/ingest/status — TTL/hash tracking state, joined with source metadata
router.get("/status", async (req, res) => {
  try {
    const rows = await FetchTracking.find();
    const byKey = Object.fromEntries(rows.map((r) => [r.sourceKey, r]));

    const merged = ALL_SOURCES_META.filter((s) => !s.optional || process.env.OTX_API_KEY).map((meta) => ({
      key: meta.key,
      name: meta.name,
      category: meta.category,
      format: meta.format,
      lastFetchAt: byKey[meta.key]?.lastFetchAt || null,
      lastStatus: byKey[meta.key]?.lastStatus || "never run",
      lastItemsUpserted: byKey[meta.key]?.lastItemsUpserted ?? null,
      lastError: byKey[meta.key]?.lastError || null,
    }));

    res.json(merged);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
