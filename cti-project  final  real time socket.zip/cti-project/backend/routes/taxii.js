import { Router } from "express";
import Threat from "../../database/models/Threat.js";

/**
 * TAXII 2.1-SHAPED endpoints — structured the way the TAXII 2.1 spec
 * (docs.oasis-open.org/cti/taxii/v2.1/) lays out discovery/api-root/
 * collections/objects, serving our MongoDB threat data as STIX-ish
 * "indicator" objects. This is NOT a certified TAXII 2.1 server (that's
 * what OpenTAXII/DeltaTI provide) — it's a simplified, honest approximation
 * built for this project, useful for demonstrating the concept and for
 * any tool that just needs predictable, spec-shaped JSON.
 */

const router = Router();
const API_ROOT = "cti-aggregator";

// GET /taxii2/  — server discovery
router.get("/", (req, res) => {
  res.json({
    title: "CTI Aggregator TAXII Server (student project, DeltaTI-inspired)",
    description: "Serves normalized threat indicators in a TAXII 2.1-shaped API.",
    default: `/taxii2/${API_ROOT}/`,
    api_roots: [`/taxii2/${API_ROOT}/`],
  });
});

// GET /taxii2/cti-aggregator/  — api root info
router.get(`/${API_ROOT}`, (req, res) => {
  res.json({
    title: "CTI Aggregator API Root",
    description: "Threat indicators normalized from CISA, NVD, and OTX.",
    versions: ["application/taxii+json;version=2.1"],
    max_content_length: 10485760,
  });
});

// GET /taxii2/cti-aggregator/collections/  — one collection per severity band
router.get(`/${API_ROOT}/collections`, async (req, res) => {
  try {
    const threats = await Threat.find();
    const counts = {};
    threats.forEach((t) => { counts[t.severity] = (counts[t.severity] || 0) + 1; });

    res.json({
      collections: Object.keys(counts).map((sev) => ({
        id: sev.toLowerCase(),
        title: `${sev}_Confidence_Indicators`,
        description: `Indicators scored as ${sev} severity by the deterministic scoring engine`,
        can_read: true,
        can_write: false,
        media_types: ["application/stix+json;version=2.1"],
        item_count: counts[sev],
      })),
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /taxii2/cti-aggregator/collections/:id/objects/  — STIX-shaped indicator objects
router.get(`/${API_ROOT}/collections/:id/objects`, async (req, res) => {
  try {
    const severity = req.params.id;
    const threats = await Threat.find({ severity: new RegExp(`^${severity}$`, "i") });

    const objects = threats.map((t) => ({
      type: "indicator",
      spec_version: "2.1",
      id: `indicator--${t._id}`,
      created: t.createdAt,
      modified: t.updatedAt,
      name: t.title,
      description: t.summary,
      indicator_types: [`${t.severity.toLowerCase()}-severity`],
      pattern: t.cve !== "—" ? `[vulnerability:cve = '${t.cve}']` : `[x-custom:title = '${t.title.replace(/'/g, "")}']`,
      pattern_type: "stix",
      valid_from: t.createdAt,
      confidence: t.severityScore ?? 50,
      labels: t.mitre || [],
    }));

    res.json({ objects });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
