import { Router } from "express";
import Threat from "../../database/models/Threat.js";
import RawIndicator from "../../database/models/RawIndicator.js";

const router = Router();

// GET /api/indicators — flattens IOCs across every threat into a single table
router.get("/", async (req, res) => {
  try {
    const threats = await Threat.find();
    const rows = threats.flatMap((t) => [
      ...t.iocs.ips.map((v) => ({ type: "IP", value: v, threatId: t._id, threatTitle: t.title, cve: t.cve, severity: t.severity })),
      ...t.iocs.domains.map((v) => ({ type: "Domain", value: v, threatId: t._id, threatTitle: t.title, cve: t.cve, severity: t.severity })),
      ...t.iocs.hashes.map((v) => ({ type: "Hash", value: v, threatId: t._id, threatTitle: t.title, cve: t.cve, severity: t.severity })),
    ]);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/indicators/raw-count — total indicators ingested at scale via batch processing
router.get("/raw-count", async (req, res) => {
  try {
    const total = await RawIndicator.countDocuments();
    const indiaTotal = await RawIndicator.countDocuments({ isIndiaRelated: true });
    const bySource = await RawIndicator.aggregate([
      { $group: { _id: "$source", count: { $sum: 1 } } },
      { $sort: { count: -1 } },
    ]);
    res.json({ total, indiaTotal, bySource });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/indicators/india — indicators geolocated to India (see backend/services/geoip.js)
router.get("/india", async (req, res) => {
  try {
    const items = await RawIndicator.find({ isIndiaRelated: true }).sort({ lastSeen: -1 }).limit(200);
    const total = await RawIndicator.countDocuments({ isIndiaRelated: true });
    res.json({ total, items });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
