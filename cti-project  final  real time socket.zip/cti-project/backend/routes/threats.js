import { Router } from "express";
import Threat from "../../database/models/Threat.js";
import { weeklyTrendSeed } from "../../database/seed/seedData.js";

const router = Router();

// GET /api/threats?severity=Critical&search=exchange
router.get("/", async (req, res) => {
  try {
    const { severity, search } = req.query;
    const query = {};
    if (severity && severity !== "All") query.severity = severity;
    if (search) {
      const re = new RegExp(search, "i");
      query.$or = [{ title: re }, { cve: re }, { malware: re }];
    }
    const threats = await Threat.find(query).sort({ createdAt: -1 });
    res.json(threats);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/threats/stats/summary
router.get("/stats/summary", async (req, res) => {
  try {
    const threats = await Threat.find();
    const bySeverity = threats.reduce((acc, t) => {
      acc[t.severity] = (acc[t.severity] || 0) + 1;
      return acc;
    }, {});
    const malwareCounts = threats.reduce((acc, t) => {
      if (t.malware && t.malware !== "—") acc[t.malware] = (acc[t.malware] || 0) + 1;
      return acc;
    }, {});
    const trendingMalware = Object.entries(malwareCounts)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count);

    res.json({ total: threats.length, bySeverity, trendingMalware, weeklyTrend: weeklyTrendSeed });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/threats/:id
router.get("/:id", async (req, res) => {
  try {
    const threat = await Threat.findById(req.params.id);
    if (!threat) return res.status(404).json({ error: "Threat not found" });
    res.json(threat);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
