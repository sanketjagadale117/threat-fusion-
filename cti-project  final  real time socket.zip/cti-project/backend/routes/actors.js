import { Router } from "express";
import ThreatActor from "../../database/models/ThreatActor.js";
import Threat from "../../database/models/Threat.js";

const router = Router();

// GET /api/actors
router.get("/", async (req, res) => {
  try {
    const actors = await ThreatActor.find();
    const threats = await Threat.find();
    const withCounts = actors.map((a) => ({
      ...a.toObject(),
      threatCount: threats.filter((t) => a.malware.includes(t.malware)).length,
    }));
    res.json(withCounts);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
