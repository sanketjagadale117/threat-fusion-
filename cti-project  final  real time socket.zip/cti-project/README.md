# CTI Aggregation Platform — Full Stack (MERN + DeltaTI-inspired pipeline)

Three separate folders — `database/`, `backend/`, `frontend/` — each with its
own `package.json`, so you can `npm install` and run each independently in
VS Code. Real MongoDB, real Express API, real React + Tailwind frontend,
and a genuinely automated ingestion pipeline inspired by *"DeltaTI: Threat
Intelligence Aggregation Platform"* (Gad et al., IEEE 3SCEA 2026).

```
cti-project/
  database/    Mongoose models + seed script (own package.json)
  backend/     Express API + scoring/fetching/metrics services + TAXII-shaped routes
  frontend/    React + Vite + Tailwind — 7 pages, live data
```

## What's implemented from the paper

| Paper concept | Where | What it does |
|---|---|---|
| **Algorithm 1** — Event-Driven Incremental Normalization | `backend/services/fetcher.js` | Content-hash comparison skips reprocessing unchanged data; polymorphic parser dispatches on format (JSON / CSV / unstructured text + regex) |
| **Algorithm 2** — Resilient Multi-Source Fetching | Same file | TTL check before re-fetching, exponential backoff retry (2s/4s/8s), batched upserts |
| **Algorithm 3** — Multi-Factor Severity Scoring | `backend/services/scoring.js` | Source reliability (30%) + type severity (30%) + keyword boost (+20/+10) + corroboration (ln(count)×2), clamped 0–100 |
| **13+ feeds, auto-run every 15 min** | `backend/services/scheduler.js` | `node-cron` triggers `runAllFetchers()` automatically — no button needed for this to happen |
| **Batch processing, 500 records/commit** | `backend/services/batch.js` | Generic `batchUpsert()` used for both the bulk indicator lists and the CVE-style threat reports |
| **Performance Metrics system** | `backend/services/metrics.js` + `backend/routes/metrics.js` | `MetricTimer` class instruments every pipeline stage; 10 REST endpoints expose throughput/latency/trend data |
| **TAXII 2.1-shaped endpoints** | `backend/routes/taxii.js` | Discovery → api-root → collections → objects, STIX-ish indicators (see honesty note below) |

## 1. Check before you start

- [ ] Node.js **v18+** (needed for the built-in `fetch` the live fetcher uses) → `node -v`
- [ ] npm → `npm -v`
- [ ] MongoDB — local install (mongodb.com/try/download/community) or a free Atlas cluster (mongodb.com/cloud/atlas/register)
- [ ] Ports 5000 (backend) and 5173 (frontend) free
- [ ] Internet connection — the scheduler and "Run live ingestion" button call real public feeds

## 2. Setup — three terminals, in order

### Terminal 1 — database
```bash
cd database
npm install
cp .env.example .env      # edit MONGO_URI if using Atlas
npm run seed
```
Expect: `Done. Seeded 8 threats, 4 actors, 5 alerts.`

### Terminal 2 — backend
```bash
cd backend
npm install
cp .env.example .env      # MONGO_URI must match database/.env
npm run dev
```
Expect:
```
MongoDB connected -> ...
CTI backend running at http://localhost:5000
TAXII-shaped endpoints at http://localhost:5000/taxii2/
Performance metrics at http://localhost:5000/api/metrics/summary
Scheduler active: all sources will be checked automatically every 15 minutes.
```

### Terminal 3 — frontend
```bash
cd frontend
npm install
npm run dev
```
Open `http://localhost:5173`

## 3. What to try

- **Dashboard, Threat feed, Indicators, MITRE map, Threat actors, Alerts** — same as before, now backed by real data plus your seed data.
- **Pipeline (new 7th tab)** — shows all 13 configured sources, their category (Vulnerabilities/Malware/IP/Phishing/ThreatIntel), format (JSON/CSV/Text), last status, and item counts. Also shows live performance-metric summary cards (throughput, items normalized, raw indicators stored, India-related count).
- **"Run live ingestion" button** (top right) — manually triggers the same pipeline the scheduler runs automatically every 15 minutes. Click it, wait a few seconds, then check the Pipeline and Threat feed pages.
- **Indicators page — "India only" toggle** — see Section 3a below.
- The scheduler will also fire on its own every 15 minutes with the backend running — check the backend terminal logs.

### 3a. India-focused view (GeoIP-based, since there's no Indian equivalent of CISA/NVD)

CERT-In (India's national CERT) does not publish a structured, machine-readable
API or RSS feed — only web-page advisories. There is no direct Indian
equivalent to swap in for CISA/NVD. Instead, this project takes every **IP**
indicator already being collected from the global feeds (Spamhaus, Blocklist.de,
Feodo Tracker, etc.) and checks its geolocation via a free GeoIP service
(`ip-api.com`, no key needed). Any IP that resolves to India gets flagged.

**"India only" mode (top-right toggle, next to Refresh):** turns it on
app-wide — Dashboard, Threat feed, and Search all switch to showing *only*
threats flagged `isIndiaRelated: true`. Everything else (global CVEs from
CISA/NVD, non-India IPs) is hidden while it's on, not just tucked into a
side panel. Stat cards (Total/Critical/High) also recompute from the
filtered list so the numbers stay consistent with what's on screen.

**How an India-tagged threat gets created:** when the fetcher processes an
IP-list source (say, Spamhaus DROP) and finds that some of its IPs resolve to
India, it creates a *dedicated* Threat entry like *"Spamhaus DROP: 3
indicators geolocated to India"* — separate from the general "all countries"
summary card for that same source. This is what makes India threats appear
as real entries in the Dashboard/Feed, not just a filtered table.

**Is this "an API" for India data?** Yes and no — be precise about this:
we DO call an API (`ip-api.com`), but it's a **geolocation** API ("which
country is this IP registered in?"), not a **threat-intelligence** API. It
never tells us anything is malicious — the malicious/IOC data itself still
comes entirely from the global OSINT feeds. We're just filtering those
global results by country after the fact. Say exactly this if asked:
*"We use a GeoIP API to filter global threat data by country — not an
Indian threat-intelligence API, because none exists publicly."*

**On "real-time":** the Indicators/India toggle and Dashboard both auto-poll
your own backend every 30 seconds (harmless — it's just re-reading your own
MongoDB, not hitting any external rate-limited service), so the UI updates
itself without you clicking Refresh. The underlying *data* still only
changes when the 15-minute scheduler runs or you click "Run live ingestion" —
so "real-time" here means *"the screen reflects the database within 30
seconds of it changing,"* not *"a new threat appears the instant it happens
anywhere in the world."* Genuine sub-second push (WebSockets) is a further
extension, not implemented here — say so plainly if asked.

- GeoIP lookups are cached in MongoDB (`GeoCache` collection) so the same IP
  is never looked up twice, and capped at 15 *new* lookups per source per
  ingestion cycle to respect `ip-api.com`'s free-tier rate limit (45
  requests/minute). The India-tagged count builds up gradually over a few
  ingestion cycles on a fresh database — that's expected, not a bug.

## 3b. True real-time (Socket.io / WebSocket push — genuinely instant, not polling)

Everything described above (30-second auto-refresh) is polling — the frontend
asks the backend "anything new?" on a timer. This section is different: the
**backend now pushes events to the browser the instant something happens**,
using Socket.io (WebSocket, with automatic fallback to HTTP long-polling if a
network blocks WebSockets outright).

**What's pushed, live, with no delay:**

| Event | When it fires | What you see |
|---|---|---|
| `ingestion:started` | The moment any ingestion cycle begins — manual click **or** the 15-minute auto-scheduler | Header shows "Fetching live data…" even if *you* didn't click the button — proof the background scheduler is alive |
| `ingestion:source-result` | Right after each of the 13 sources finishes (success/failed/skipped) | **Pipeline tab → "Live ingestion log"** fills in one source at a time, in real time, as the backend works through the list |
| `alert:critical` | Any threat (new or freshly re-scored) comes out Critical | A **red toast banner** pops up top-right immediately, on whichever page you're on, and the dashboard silently refreshes so the new data is already there when you look |
| `threat:new` / `threat:india` | A genuinely new Threat document is inserted (not just an existing one being re-scored) | Used internally to drive the refresh; not shown directly, but this is what a future "live feed ticker" would hook into |

**How to see this working for real:** open the app, then either wait for the
15-minute scheduler or click "Run live ingestion." Watch the **Pipeline
tab** — you'll see each source's result appear in the live log within
milliseconds of the backend actually finishing that source, not after a
fixed poll interval.

**Architecturally, what changed:**
- `backend/services/realtime.js` — thin Socket.io wrapper (`initRealtime`, `emitEvent`)
- `backend/server.js` — now creates a raw `http.createServer(app)` instead of calling `app.listen()` directly, because Socket.io needs to attach to that same underlying server to upgrade connections to WebSocket
- `backend/services/fetcher.js` — calls `emitEvent(...)` at each decision point (TTL skip, hash-match skip, success, failure, new critical threat)
- `frontend/src/App.jsx` — opens one `socket.io-client` connection on mount, listens for the events above

**Honest scope note:** this pushes *server-detected* events (new/updated data
in our own MongoDB) — it is not literally "the instant a threat happens
anywhere in the world." The underlying data still only changes when a fetch
cycle runs (every 15 min, or on demand). What's real and new here is that
**the moment our backend knows something, your browser knows it too** — zero
polling delay between server-side detection and UI update, which is the
correct definition of "real-time" for a system like this.

## 4. The 13 feeds

| # | Source | Category | Format | Needs a key? |
|---|---|---|---|---|
| 1 | CISA KEV | Vulnerabilities | JSON | No |
| 2 | NVD | Vulnerabilities | JSON | No (optional key raises rate limit) |
| 3 | URLhaus | Phishing | CSV | No |
| 4 | ThreatFox | ThreatIntel | CSV | No |
| 5 | MalwareBazaar | Malware | CSV | No |
| 6 | SSL Blacklist | Malware | CSV | No |
| 7 | Feodo Tracker | IP | CSV | No |
| 8 | Spamhaus DROP | IP | Text | No |
| 9 | Blocklist.de | IP | Text | No |
| 10 | CINS Army List | IP | Text | No |
| 11 | DShield Block List | IP | Text | No |
| 12 | Emerging Threats | IP | Text | No |
| 13 | AlienVault OTX | ThreatIntel | JSON | **Yes** — free at otx.alienvault.com, add to `backend/.env` as `OTX_API_KEY` |

12 run out of the box; OTX is the 13th, off until you add a free key. All of
these are free, publicly-documented feeds maintained by CISA, NIST, and
abuse.ch — nothing here requires a paid subscription.

**Reality check, said plainly:** these are live third-party services with
public but occasionally-changing formats. If abuse.ch or another provider
changes their CSV column order since this was written, that one source will
show `failed` in the Pipeline tab without breaking anything else — each
source is fetched and parsed independently, exactly like Algorithm 2 in the
paper is designed to isolate failures. This is itself listed as a known
limitation in the paper too (Section X-B: *"If a source provider modifies
their API schema, the ingestion pipeline is prone to failure until manual
code updates are applied"*) — so if you hit this, you're reproducing a
documented limitation, not something broken about your setup.

## 5. Honesty notes (say these plainly in your report/viva)

- **TAXII endpoints are TAXII-2.1-*shaped*, not a certified TAXII server.** Same discovery → collections → objects structure, STIX-ish indicator objects — but no auth, no content negotiation, no full spec compliance. That's what OpenTAXII (which DeltaTI itself uses) provides.
- **Docker containerization was not implemented.** The paper deploys via 2 Docker containers; this project runs as plain Node processes. Functionally equivalent for a demo, but not containerized.
- **MariaDB vs MongoDB.** The paper uses MariaDB (relational); this project uses MongoDB (document-based) — a deliberate substitution, not an oversight, since the rest of your MERN stack is already Mongo-based.
- **Accuracy metrics (`/api/metrics/accuracy`) are a stub.** True/false positive tracking requires labeled ground-truth data this project doesn't collect. The endpoint says so honestly rather than returning fake numbers.
- **This is a subset, not a full DeltaTI clone.** Not implemented: Docker, MariaDB, role-based access control, PhishTank integration, the full 100k/sec throughput benchmark (irrelevant at demo scale). Describe this as "a DeltaTI-inspired subset implementation focused on the scoring, fetching, and metrics algorithms" in your report.

## 6. Optional: enabling OTX

Add to `backend/.env`:
```
OTX_API_KEY=your_key_here
```
Restart the backend. OTX will then appear as the 13th source in the Pipeline tab.

## 7. API endpoint reference

| Endpoint | Returns |
|---|---|
| `GET /api/threats?severity=Critical&search=exchange` | Filtered threat list |
| `GET /api/threats/:id` | One threat, full detail |
| `GET /api/threats/stats/summary` | Totals, severity counts, trending malware, weekly trend |
| `GET /api/indicators` | Curated IOCs (from Threat docs) for the Indicators page |
| `GET /api/indicators/raw-count` | Total raw indicators ingested at scale, by source (includes `indiaTotal`) |
| `GET /api/indicators/india` | IP indicators geolocated to India (GeoIP-tagged, see Section 3a) |
| `GET /api/mitre` | MITRE technique catalog + which are "active" |
| `GET /api/actors` | Threat actor profiles with live threat counts |
| `GET /api/alerts` | Alert log, with related threat populated |
| `POST /api/ingest/run` | Manually triggers all 13 fetchers |
| `GET /api/ingest/status` | Per-source status, format, category, last run |
| `GET /api/metrics` | Latest raw performance-metric records |
| `GET /api/metrics/summary` | Aggregated report per pipeline stage |
| `GET /api/metrics/by-source` | Per-source throughput/volume breakdown |
| `GET /api/metrics/by-type/:type` | Filter by ingestion/normalization/scoring |
| `GET /api/metrics/trends?hours=24` | Time-bucketed historical trend |
| `GET /api/metrics/throughput` | Latest throughput per operation |
| `GET /api/metrics/accuracy` | Stub — see honesty notes |
| `GET /api/metrics/latest` | Most recent metric per operation |
| `GET /api/metrics/count` | Total metric records, by type |
| `DELETE /api/metrics` | Clears metrics (useful before a clean demo run) |
| `GET /taxii2/...` | TAXII-shaped endpoints — see Section 5 |

## 8. What's still not implemented

- NLP-based entity extraction (NER) or AI summarization — the paper's whole
  premise is avoiding this in favor of transparent scoring, so this is by
  design, not a gap, unless you specifically want it for your own project
- Auth (JWT login/signup)
- Real alert delivery (Email/Telegram actually sending — alerts are stored, not sent)
- Docker, MariaDB, RBAC (see Section 5)

## Troubleshooting

- **"MongoDB connection failed"** → MongoDB isn't running, or `.env` MONGO_URI mismatches between `database/` and `backend/`
- **Pipeline tab shows all "failed"** → check your internet connection first; if only 1-2 sources fail repeatedly, that provider likely changed their format (see Section 4)
- **"Run live ingestion" shows "skipped (TTL not expired)" for everything** → that's Algorithm 2 working as designed; wait 15 minutes or restart the backend (tracking resets are per-process, but `FetchTracking` is persisted in MongoDB, so a restart alone won't reset it — run `db.fetchtrackings.deleteMany({})` in `mongosh` if you want to force a fresh run for a demo)
- **Frontend shows "Can't reach the backend"** → backend isn't running, or its MongoDB connection failed
- **Empty dashboard, no errors** → you forgot `npm run seed` in `database/`
- **CORS error in browser console** → backend must be running on port 5000 exactly
