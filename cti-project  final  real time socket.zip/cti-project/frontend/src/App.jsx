import { useEffect, useState } from "react";
import { io } from "socket.io-client";
import {
  Search, Bell, LayoutDashboard, Rss, Fingerprint, Network, Users, ShieldAlert,
  RefreshCw, Clock, ChevronRight, TrendingUp, X, ExternalLink, Wrench, Tags,
  Mail, Send, MessageSquare, Globe, WifiOff, Zap, Activity, CheckCircle2, XCircle, MinusCircle, MapPin
} from "lucide-react";

const API = "http://localhost:5000/api";

const SEV_STYLE = {
  Critical: { bar: "bg-red-500", chip: "bg-red-500/10 text-red-400 border-red-500/30" },
  High: { bar: "bg-orange-500", chip: "bg-orange-500/10 text-orange-400 border-orange-500/30" },
  Medium: { bar: "bg-amber-500", chip: "bg-amber-500/10 text-amber-400 border-amber-500/30" },
  Low: { bar: "bg-teal-500", chip: "bg-teal-500/10 text-teal-400 border-teal-500/30" },
};
const CHANNEL_ICON = { Email: Mail, Telegram: Send, Slack: MessageSquare, Discord: MessageSquare };

const NAV = [
  { key: "dashboard", icon: LayoutDashboard, label: "Dashboard" },
  { key: "feed", icon: Rss, label: "Threat feed" },
  { key: "indicators", icon: Fingerprint, label: "Indicators" },
  { key: "mitre", icon: Network, label: "MITRE map" },
  { key: "actors", icon: Users, label: "Threat actors" },
  { key: "alerts", icon: ShieldAlert, label: "Alerts" },
  { key: "pipeline", icon: Activity, label: "Pipeline" },
];

function timeAgo(iso) {
  if (!iso) return "";
  const mins = Math.floor((Date.now() - new Date(iso).getTime()) / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

function SevChip({ severity }) {
  const s = SEV_STYLE[severity] || SEV_STYLE.Low;
  return <span className={`text-[11px] px-1.5 py-0.5 rounded border ${s.chip}`}>{severity}</span>;
}

function ThreatRow({ t, onClick }) {
  const s = SEV_STYLE[t.severity] || SEV_STYLE.Low;
  return (
    <button onClick={onClick} className="w-full flex gap-3 px-4 py-3 hover:bg-slate-800/40 text-left border-b border-slate-800 last:border-b-0">
      <span className={`w-1 rounded-full ${s.bar}`} />
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap mb-1">
          <SevChip severity={t.severity} />
          {t.severityScore != null && <span className="text-[10px] text-slate-600">score {t.severityScore}/100</span>}
          <span className="text-[11px] font-mono text-slate-500">{t.cve}</span>
          <span className="text-[11px] text-slate-600">· {t.source}</span>
          {t.malware !== "—" && <span className="text-[11px] text-slate-600">· {t.malware}</span>}
        </div>
        <p className="text-sm text-slate-200 truncate">{t.title}</p>
        <p className="text-xs text-slate-500 mt-0.5 line-clamp-1">{t.summary}</p>
      </div>
      <div className="flex flex-col items-end justify-between shrink-0">
        <span className="text-[11px] text-slate-500 flex items-center gap-1"><Clock className="w-3 h-3" />{timeAgo(t.createdAt)}</span>
        <ChevronRight className="w-4 h-4 text-slate-600" />
      </div>
    </button>
  );
}

function DetailModal({ threat, onClose }) {
  if (!threat) return null;
  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-slate-900 border border-slate-800 rounded-lg w-full max-w-2xl max-h-[85vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between px-5 py-4 border-b border-slate-800 sticky top-0 bg-slate-900">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <SevChip severity={threat.severity} />
              <span className="text-[11px] font-mono text-slate-500">{threat.cve}</span>
              <span className="text-[11px] text-slate-600">· {threat.source}</span>
            </div>
            <h2 className="text-base font-medium text-slate-100">{threat.title}</h2>
          </div>
          <button onClick={onClose} className="text-slate-500 hover:text-slate-200 shrink-0 ml-3"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-5 space-y-5">
          <div><p className="text-xs text-slate-500 mb-1.5">AI summary</p><p className="text-sm text-teal-300 bg-teal-500/5 border border-teal-500/20 rounded-md px-3 py-2">{threat.summary}</p></div>
          {threat.severityScore != null && (
            <div>
              <p className="text-xs text-slate-500 mb-1.5">Confidence score (Algorithm 3: source reliability + type + keywords + corroboration)</p>
              <div className="flex items-center gap-2">
                <div className="h-2 flex-1 bg-slate-800 rounded-full overflow-hidden"><div className="h-full bg-purple-500" style={{ width: `${threat.severityScore}%` }} /></div>
                <span className="text-xs font-mono text-purple-300">{threat.severityScore}/100</span>
              </div>
            </div>
          )}
          <div><p className="text-xs text-slate-500 mb-1.5">Description</p><p className="text-sm text-slate-300 leading-relaxed">{threat.description}</p></div>
          <div><p className="text-xs text-slate-500 mb-1.5">Affected software</p><p className="text-sm text-slate-300">{threat.affected}</p></div>
          <div><p className="text-xs text-slate-500 mb-1.5 flex items-center gap-1.5"><Wrench className="w-3.5 h-3.5" /> Mitigation</p><p className="text-sm text-slate-300">{threat.mitigation}</p></div>
          <div>
            <p className="text-xs text-slate-500 mb-1.5 flex items-center gap-1.5"><Tags className="w-3.5 h-3.5" /> MITRE ATT&CK</p>
            <div className="flex flex-wrap gap-1.5">
              {(threat.mitre || []).map((id) => (
                <span key={id} className="text-xs px-2 py-1 rounded-md bg-slate-800 border border-slate-700 text-slate-300 font-mono">{id}</span>
              ))}
            </div>
          </div>
          <div>
            <p className="text-xs text-slate-500 mb-1.5">Indicators of compromise</p>
            <div className="space-y-1 text-xs font-mono">
              {threat.iocs?.ips?.map((ip) => <div key={ip} className="text-slate-400">IP &nbsp; {ip}</div>)}
              {threat.iocs?.domains?.map((d) => <div key={d} className="text-slate-400">Domain &nbsp; {d}</div>)}
              {threat.iocs?.hashes?.map((h) => <div key={h} className="text-slate-400">Hash &nbsp; {h}</div>)}
              {(!threat.iocs?.ips?.length && !threat.iocs?.domains?.length && !threat.iocs?.hashes?.length) && (
                <p className="text-slate-600 font-sans">No IOCs extracted for this entry.</p>
              )}
            </div>
          </div>
          <div>
            <p className="text-xs text-slate-500 mb-1.5">Related articles</p>
            {(threat.articles || []).map((a, i) => (
              <div key={i} className="flex items-center gap-1.5 text-sm text-slate-300"><ExternalLink className="w-3.5 h-3.5 text-slate-500" /> {a.title} <span className="text-slate-600">— {a.source}</span></div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Pages (all receive live data via props) ---------------- */

function DashboardPage({ threats, stats, alerts, onSelect, indiaOnly }) {
  const maxWeek = stats?.weeklyTrend?.length ? Math.max(...stats.weeklyTrend.map((w) => w.count)) : 1;
  const maxMal = stats?.trendingMalware?.length ? Math.max(...stats.trendingMalware.map((m) => m.count)) : 1;

  // In India-only mode, recompute the top counts from the already-filtered
  // threats list instead of the global /stats/summary numbers (which cover
  // every country) — otherwise "Total threats: 47" would contradict a feed
  // that's only showing 3 India-tagged entries.
  const totalCount = indiaOnly ? threats.length : stats?.total ?? "—";
  const criticalCount = indiaOnly ? threats.filter((t) => t.severity === "Critical").length : stats?.bySeverity?.Critical ?? 0;
  const highCount = indiaOnly ? threats.filter((t) => t.severity === "High").length : stats?.bySeverity?.High ?? 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-medium text-slate-100">
          {indiaOnly ? "Today's threats — India only" : "Today's threats"}
        </h1>
        <div className="flex items-center gap-1.5 text-xs text-teal-400"><span className="w-1.5 h-1.5 rounded-full bg-teal-400 animate-pulse" /> Live</div>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Total threats", value: totalCount, tone: "text-slate-100" },
          { label: "Critical", value: criticalCount, tone: "text-red-400" },
          { label: "High", value: highCount, tone: "text-orange-400" },
          { label: "Active alerts", value: alerts.length, tone: "text-teal-400" },
        ].map((s) => (
          <div key={s.label} className="bg-slate-900 border border-slate-800 rounded-lg p-4">
            <p className="text-xs text-slate-500 mb-1">{s.label}</p>
            <p className={`text-2xl font-medium ${s.tone}`}>{s.value}</p>
          </div>
        ))}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <div className="lg:col-span-3 bg-slate-900 border border-slate-800 rounded-lg">
          <div className="px-4 py-3 border-b border-slate-800"><span className="text-sm font-medium text-slate-200">Live threat feed</span></div>
          {threats.length === 0 && (
            <p className="p-4 text-sm text-slate-500">
              {indiaOnly ? "No India-geolocated threats yet — run live ingestion, then wait a few cycles for GeoIP lookups to build up." : "No threats yet."}
            </p>
          )}
          {threats.slice(0, 5).map((t) => <ThreatRow key={t._id} t={t} onClick={() => onSelect(t)} />)}
        </div>
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
            <p className="text-sm font-medium text-slate-200 mb-3 flex items-center gap-1.5"><TrendingUp className="w-4 h-4 text-teal-400" /> Trending malware</p>
            {(stats?.trendingMalware || []).map((m) => (
              <div key={m.name} className="mb-2.5">
                <div className="flex justify-between text-xs mb-1"><span className="text-slate-300">{m.name}</span><span className="text-slate-500">{m.count}</span></div>
                <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden"><div className="h-full bg-teal-500 rounded-full" style={{ width: `${(m.count / maxMal) * 100}%` }} /></div>
              </div>
            ))}
          </div>
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
            <p className="text-sm font-medium text-slate-200 mb-3">Threats this week</p>
            <div className="flex items-end justify-between gap-2 h-28">
              {(stats?.weeklyTrend || []).map((w) => (
                <div key={w.day} className="flex-1 flex flex-col items-center gap-1.5">
                  <div className="w-full bg-slate-800 rounded-t-sm flex items-end" style={{ height: "100%" }}>
                    <div className="w-full bg-teal-500/70 rounded-t-sm" style={{ height: `${(w.count / maxWeek) * 100}%` }} />
                  </div>
                  <span className="text-[10px] text-slate-500">{w.day}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function FeedPage({ threats, onSelect }) {
  const [filter, setFilter] = useState("All");
  const filtered = filter === "All" ? threats : threats.filter((t) => t.severity === filter);
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-medium text-slate-100">Threat feed</h1>
        <div className="flex gap-1 text-xs">
          {["All", "Critical", "High", "Medium", "Low"].map((f) => (
            <button key={f} onClick={() => setFilter(f)} className={`px-2.5 py-1 rounded-md border ${filter === f ? "border-teal-600 text-teal-300 bg-teal-500/10" : "border-slate-800 text-slate-500 hover:text-slate-300"}`}>{f}</button>
          ))}
        </div>
      </div>
      <div className="bg-slate-900 border border-slate-800 rounded-lg">
        {filtered.length === 0 && <p className="p-4 text-sm text-slate-500">No threats match this filter.</p>}
        {filtered.map((t) => <ThreatRow key={t._id} t={t} onClick={() => onSelect(t)} />)}
      </div>
    </div>
  );
}

function IndicatorsPage({ indicators }) {
  const [mode, setMode] = useState("all"); // "all" | "india"
  const [indiaRows, setIndiaRows] = useState([]);
  const [indiaTotal, setIndiaTotal] = useState(0);
  const [loadingIndia, setLoadingIndia] = useState(false);
  const [loadedOnce, setLoadedOnce] = useState(false);

  async function loadIndia() {
    setLoadingIndia(true);
    try {
      const res = await fetch(`${API}/indicators/india`);
      const data = await res.json();
      setIndiaRows(data.items || []);
      setIndiaTotal(data.total || 0);
    } catch (err) {
      // ignore — page still renders, just shows an empty state
    } finally {
      setLoadingIndia(false);
      setLoadedOnce(true);
    }
  }

  useEffect(() => {
    if (mode === "india" && !loadedOnce) loadIndia();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode]);

  const rows = mode === "india" ? indiaRows : indicators;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-medium text-slate-100">Indicators of compromise</h1>
          <p className="text-xs text-slate-500 mt-1">
            {mode === "india"
              ? "IP indicators geolocated to India (via free GeoIP lookup — no Indian government API exists for this)."
              : "Curated IOCs pulled from current threat entries."}
          </p>
        </div>
        <div className="flex gap-1 text-xs">
          <button onClick={() => setMode("all")} className={`px-2.5 py-1 rounded-md border ${mode === "all" ? "border-teal-600 text-teal-300 bg-teal-500/10" : "border-slate-800 text-slate-500 hover:text-slate-300"}`}>
            All sources
          </button>
          <button onClick={() => setMode("india")} className={`px-2.5 py-1 rounded-md border ${mode === "india" ? "border-orange-600 text-orange-300 bg-orange-500/10" : "border-slate-800 text-slate-500 hover:text-slate-300"}`}>
            India only{indiaTotal > 0 ? ` (${indiaTotal})` : ""}
          </button>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-slate-500 border-b border-slate-800">
              <th className="px-4 py-2.5 font-normal">Type</th>
              <th className="px-4 py-2.5 font-normal">Value</th>
              <th className="px-4 py-2.5 font-normal">{mode === "india" ? "Source" : "Related threat"}</th>
              <th className="px-4 py-2.5 font-normal">{mode === "india" ? "Last seen" : "Severity"}</th>
            </tr>
          </thead>
          <tbody>
            {loadingIndia && mode === "india" && (
              <tr><td colSpan={4} className="px-4 py-4 text-sm text-slate-500">Checking IP geolocations…</td></tr>
            )}
            {!loadingIndia && rows.map((r, i) => (
              <tr key={r._id || i} className="border-b border-slate-800 last:border-b-0 hover:bg-slate-800/40">
                <td className="px-4 py-2.5 text-slate-400 flex items-center gap-1.5"><Globe className="w-3.5 h-3.5" />{r.type}</td>
                <td className="px-4 py-2.5 font-mono text-slate-300">{r.value}</td>
                {mode === "india" ? (
                  <>
                    <td className="px-4 py-2.5 text-slate-400">{r.source}</td>
                    <td className="px-4 py-2.5 text-slate-500 text-xs">{r.lastSeen ? new Date(r.lastSeen).toLocaleString() : "—"}</td>
                  </>
                ) : (
                  <>
                    <td className="px-4 py-2.5 text-slate-400">{r.cve !== "—" ? r.cve : r.threatTitle}</td>
                    <td className="px-4 py-2.5"><SevChip severity={r.severity} /></td>
                  </>
                )}
              </tr>
            ))}
            {!loadingIndia && rows.length === 0 && (
              <tr><td colSpan={4} className="px-4 py-4 text-sm text-slate-500">
                {mode === "india" ? "No India-geolocated IPs yet — run live ingestion first, then check back (GeoIP lookups are rate-limited so they build up gradually)." : "No IOCs yet."}
              </td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function MitrePage({ mitre }) {
  const active = new Set(mitre?.active || []);
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-lg font-medium text-slate-100">MITRE ATT&CK coverage</h1>
        <p className="text-xs text-slate-500 mt-1">Highlighted techniques were observed in today's threat data.</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {(mitre?.catalog || []).map((tac) => (
          <div key={tac.tactic} className="bg-slate-900 border border-slate-800 rounded-lg p-4">
            <p className="text-sm font-medium text-slate-200 mb-3">{tac.tactic}</p>
            <div className="space-y-2">
              {tac.techniques.map((tech) => {
                const isActive = active.has(tech.id);
                return (
                  <div key={tech.id} className={`text-xs px-2.5 py-2 rounded-md border ${isActive ? "bg-purple-500/10 border-purple-500/30 text-purple-300" : "bg-slate-800/50 border-slate-800 text-slate-500"}`}>
                    <span className="font-mono">{tech.id}</span> · {tech.name}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ActorsPage({ actors }) {
  return (
    <div className="space-y-4">
      <h1 className="text-lg font-medium text-slate-100">Threat actors</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {actors.map((a) => (
          <div key={a._id} className="bg-slate-900 border border-slate-800 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-medium text-slate-100">{a.name}</p>
              <span className="text-[11px] text-slate-500">{a.threatCount} active threat{a.threatCount !== 1 ? "s" : ""}</span>
            </div>
            <p className="text-xs text-slate-500 mb-3">aka {a.aliases?.join(", ")}</p>
            <p className="text-xs text-slate-500 mb-1.5">Associated malware</p>
            <div className="flex flex-wrap gap-1.5 mb-3">
              {a.malware.map((m) => <span key={m} className="text-xs px-2 py-1 rounded-md bg-slate-800 border border-slate-700 text-slate-300">{m}</span>)}
            </div>
            <p className="text-xs text-slate-500 mb-1.5">Known TTPs</p>
            <div className="flex flex-wrap gap-1.5">
              {a.ttps.map((id) => <span key={id} className="text-xs font-mono px-2 py-1 rounded-md bg-purple-500/10 border border-purple-500/30 text-purple-300">{id}</span>)}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function AlertsPage({ alerts }) {
  return (
    <div className="space-y-4">
      <h1 className="text-lg font-medium text-slate-100">Alert log</h1>
      <div className="bg-slate-900 border border-slate-800 rounded-lg">
        {alerts.map((a) => {
          const s = SEV_STYLE[a.severity];
          const Icon = CHANNEL_ICON[a.channel] || Mail;
          return (
            <div key={a._id} className="flex items-center gap-3 px-4 py-3 border-b border-slate-800 last:border-b-0">
              <span className={`w-1 h-8 rounded-full ${s.bar}`} />
              <Icon className="w-4 h-4 text-slate-500 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm text-slate-200 truncate">{a.title}</p>
                <p className="text-xs text-slate-500">via {a.channel} {a.threat ? `· ${a.threat.cve !== "—" ? a.threat.cve : a.threat.title}` : ""}</p>
              </div>
              <SevChip severity={a.severity} />
              <span className="text-[11px] text-slate-500 flex items-center gap-1 shrink-0"><Clock className="w-3 h-3" />{timeAgo(a.createdAt)}</span>
            </div>
          );
        })}
        {alerts.length === 0 && <p className="p-4 text-sm text-slate-500">No alerts yet.</p>}
      </div>
    </div>
  );
}

const STATUS_ICON = { success: CheckCircle2, failed: XCircle, skipped: MinusCircle, "never run": MinusCircle };
const STATUS_COLOR = { success: "text-teal-400", failed: "text-red-400", skipped: "text-slate-500", "never run": "text-slate-600" };

function PipelinePage({ liveLog }) {
  const [sources, setSources] = useState([]);
  const [summary, setSummary] = useState([]);
  const [rawCount, setRawCount] = useState(null);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    try {
      const [srcRes, metricsRes, countRes] = await Promise.all([
        fetch(`${API}/ingest/status`),
        fetch(`${API}/metrics/summary`),
        fetch(`${API}/indicators/raw-count`),
      ]);
      setSources(await srcRes.json());
      setSummary(await metricsRes.json());
      setRawCount(await countRes.json());
    } catch (err) {
      // silently fail — this page is supplementary, App-level offline screen handles the main case
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  const ingestionRow = summary.find((s) => s._id === "ingestion");
  const normalizationRow = summary.find((s) => s._id === "normalization");
  const scoringRow = summary.find((s) => s._id === "scoring");

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-medium text-slate-100">Ingestion pipeline</h1>
          <p className="text-xs text-slate-500 mt-1">13 configured feeds, auto-run every 15 minutes, plus performance metrics for each pipeline stage.</p>
        </div>
        <button onClick={load} className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200">
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} /> Refresh
        </button>
      </div>

      {liveLog.length > 0 && (
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <p className="text-sm font-medium text-slate-200 mb-3 flex items-center gap-1.5">
            <Activity className="w-4 h-4 text-teal-400 animate-pulse" /> Live ingestion log
            <span className="text-[10px] text-slate-500 font-normal">(pushed via WebSocket, no polling)</span>
          </p>
          <div className="space-y-1.5 max-h-56 overflow-y-auto text-xs">
            {liveLog.map((entry, i) => (
              <div key={i} className="flex items-center gap-2">
                <span className="text-slate-600 shrink-0">{new Date(entry.time).toLocaleTimeString()}</span>
                <span className={`shrink-0 ${entry.status === "success" ? "text-teal-400" : entry.status === "failed" ? "text-red-400" : "text-slate-500"}`}>
                  {entry.status}
                </span>
                <span className="text-slate-300">{entry.source}</span>
                {entry.itemsUpserted != null && <span className="text-slate-500">({entry.itemsUpserted} items)</span>}
                {entry.reason && <span className="text-slate-600 truncate">— {entry.reason}</span>}
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 border-t-2 border-t-teal-500">
          <p className="text-xs text-slate-500 mb-1">Ingestion runs</p>
          <p className="text-2xl font-medium text-slate-100">{ingestionRow?.count ?? 0}</p>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 border-t-2 border-t-purple-500">
          <p className="text-xs text-slate-500 mb-1">Avg scoring throughput</p>
          <p className="text-2xl font-medium text-slate-100">{scoringRow?.avgThroughput ? Math.round(scoringRow.avgThroughput) : 0}<span className="text-xs text-slate-500">/sec</span></p>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 border-t-2 border-t-orange-500">
          <p className="text-xs text-slate-500 mb-1">Items normalized</p>
          <p className="text-2xl font-medium text-slate-100">{normalizationRow?.totalItems ?? 0}</p>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 border-t-2 border-t-blue-500">
          <p className="text-xs text-slate-500 mb-1">Raw indicators stored</p>
          <p className="text-2xl font-medium text-slate-100">{rawCount?.total ?? 0}</p>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 border-t-2 border-t-amber-500">
          <p className="text-xs text-slate-500 mb-1">India-related (GeoIP)</p>
          <p className="text-2xl font-medium text-slate-100">{rawCount?.indiaTotal ?? 0}</p>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-lg">
        <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <span className="text-sm font-medium text-slate-200">Configured sources</span>
          <span className="text-xs text-slate-500">{sources.length} feeds</span>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-slate-500 border-b border-slate-800">
              <th className="px-4 py-2.5 font-normal">Source</th>
              <th className="px-4 py-2.5 font-normal">Category</th>
              <th className="px-4 py-2.5 font-normal">Format</th>
              <th className="px-4 py-2.5 font-normal">Status</th>
              <th className="px-4 py-2.5 font-normal">Last items</th>
              <th className="px-4 py-2.5 font-normal">Last run</th>
            </tr>
          </thead>
          <tbody>
            {sources.map((s) => {
              const Icon = STATUS_ICON[s.lastStatus] || MinusCircle;
              return (
                <tr key={s.key} className="border-b border-slate-800 last:border-b-0 hover:bg-slate-800/40">
                  <td className="px-4 py-2.5 text-slate-200">{s.name}</td>
                  <td className="px-4 py-2.5 text-slate-500">{s.category}</td>
                  <td className="px-4 py-2.5"><span className="text-[11px] font-mono px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-400">{s.format}</span></td>
                  <td className={`px-4 py-2.5 flex items-center gap-1.5 ${STATUS_COLOR[s.lastStatus] || "text-slate-500"}`}>
                    <Icon className="w-3.5 h-3.5" /> {s.lastStatus}
                  </td>
                  <td className="px-4 py-2.5 text-slate-400">{s.lastItemsUpserted ?? "—"}</td>
                  <td className="px-4 py-2.5 text-slate-500">{s.lastFetchAt ? new Date(s.lastFetchAt).toLocaleTimeString() : "never"}</td>
                </tr>
              );
            })}
            {sources.length === 0 && !loading && (
              <tr><td colSpan={6} className="px-4 py-4 text-sm text-slate-500">No runs yet — click "Run live ingestion" in the header.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {rawCount?.bySource?.length > 0 && (
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <p className="text-sm font-medium text-slate-200 mb-3">Raw indicators by source</p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {rawCount.bySource.map((r) => (
              <div key={r._id} className="flex items-center justify-between text-xs bg-slate-800/50 border border-slate-800 rounded-md px-3 py-2">
                <span className="text-slate-300">{r._id}</span>
                <span className="text-slate-500 font-mono">{r.count}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------------- App shell ---------------- */

export default function App() {
  const [page, setPage] = useState("dashboard");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);

  const [threats, setThreats] = useState([]);
  const [stats, setStats] = useState(null);
  const [indicators, setIndicators] = useState([]);
  const [mitre, setMitre] = useState(null);
  const [actors, setActors] = useState([]);
  const [alerts, setAlerts] = useState([]);

  const [loading, setLoading] = useState(true);
  const [ingesting, setIngesting] = useState(false);
  const [indiaOnly, setIndiaOnly] = useState(false);
  const [socketConnected, setSocketConnected] = useState(false);
  const [toast, setToast] = useState(null);
  const [liveLog, setLiveLog] = useState([]);
  const [ingestMsg, setIngestMsg] = useState("");
  const [offline, setOffline] = useState(false);

  async function loadAll() {
    setLoading(true);
    try {
      const [tRes, sRes, iRes, mRes, aRes, alRes] = await Promise.all([
        fetch(`${API}/threats`),
        fetch(`${API}/threats/stats/summary`),
        fetch(`${API}/indicators`),
        fetch(`${API}/mitre`),
        fetch(`${API}/actors`),
        fetch(`${API}/alerts`),
      ]);
      setThreats(await tRes.json());
      setStats(await sRes.json());
      setIndicators(await iRes.json());
      setMitre(await mRes.json());
      setActors(await aRes.json());
      setAlerts(await alRes.json());
      setOffline(false);
    } catch (err) {
      setOffline(true);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadAll(); }, []);

  // Genuine real-time push via Socket.io/WebSocket — separate from the 30s
  // polling above. The backend emits these the instant something happens
  // (new critical threat scored, a source finishing its fetch, the 15-min
  // scheduler kicking off) — no waiting for the next poll tick.
  useEffect(() => {
    const socket = io("http://localhost:5000");

    socket.on("connect", () => setSocketConnected(true));
    socket.on("disconnect", () => setSocketConnected(false));

    socket.on("ingestion:started", () => {
      setIngesting(true);
      setIngestMsg("Ingestion cycle started (live push)…");
    });

    socket.on("ingestion:source-result", (entry) => {
      setLiveLog((prev) => [{ ...entry, time: new Date().toISOString() }, ...prev].slice(0, 20));
    });

    socket.on("ingestion:completed", ({ results }) => {
      setIngesting(false);
      const summary = (results || [])
        .map((r) => `${r.source}: ${r.status}${r.itemsUpserted != null ? ` (${r.itemsUpserted} items)` : ""}${r.reason ? ` — ${r.reason}` : ""}`)
        .join(" | ");
      setIngestMsg(summary || "Done.");
      loadAll();
    });

    socket.on("alert:critical", ({ threat, isIndia }) => {
      setToast({ message: `${isIndia ? "[India] " : ""}${threat.title}`, cve: threat.cve });
      loadAll();
    });

    return () => socket.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!toast) return;
    const id = setTimeout(() => setToast(null), 7000);
    return () => clearTimeout(id);
  }, [toast]);

  // Auto-refresh from our own database every 30s — this is safe to poll
  // frequently (it's just re-reading our own MongoDB via our own API, not
  // hitting any external rate-limited service), so the UI reflects new data
  // as soon as the backend's 15-minute scheduler (or a manual ingestion run)
  // adds it, without the user needing to click Refresh.
  useEffect(() => {
    const id = setInterval(() => { loadAll(); }, 30000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function runIngest() {
    setIngesting(true);
    setIngestMsg("");
    try {
      const res = await fetch(`${API}/ingest/run`, { method: "POST" });
      const data = await res.json();
      const summary = (data.results || [])
        .map((r) => `${r.source}: ${r.status}${r.itemsUpserted != null ? ` (${r.itemsUpserted} items)` : ""}${r.reason ? ` — ${r.reason}` : ""}`)
        .join(" | ");
      setIngestMsg(summary || "Done.");
      await loadAll();
    } catch (err) {
      setIngestMsg("Ingestion request failed — is the backend running?");
    } finally {
      setIngesting(false);
    }
  }

  const searchResults = search
    ? threats
        .filter((t) => !indiaOnly || t.isIndiaRelated)
        .filter((t) =>
          t.title.toLowerCase().includes(search.toLowerCase()) ||
          t.cve.toLowerCase().includes(search.toLowerCase()) ||
          t.malware.toLowerCase().includes(search.toLowerCase()))
    : null;

  if (offline) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-200 flex items-center justify-center font-sans">
        <div className="text-center max-w-sm px-6">
          <WifiOff className="w-8 h-8 text-red-400 mx-auto mb-3" />
          <p className="text-slate-200 font-medium mb-1">Can't reach the backend</p>
          <p className="text-sm text-slate-500 mb-4">
            Make sure MongoDB is running and the API server is up:<br />
            <code className="text-teal-400">cd backend && npm run dev</code>
          </p>
          <button onClick={loadAll} className="text-sm px-3 py-1.5 border border-slate-700 rounded-md hover:bg-slate-800">Retry</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 flex font-sans">
      <aside className="w-56 border-r border-slate-800 flex flex-col shrink-0 bg-gradient-to-b from-slate-900/40 to-transparent">
        <div className="h-16 flex items-center gap-2 px-5 border-b border-slate-800">
          <div className="w-7 h-7 rounded-md bg-gradient-to-br from-teal-400 to-purple-500 flex items-center justify-center shrink-0">
            <ShieldAlert className="w-4 h-4 text-slate-950" />
          </div>
          <span className="font-semibold text-slate-100 tracking-tight">CTI Aggregator</span>
        </div>
        <nav className="flex-1 py-4 px-3 space-y-1">
          {NAV.map(({ key, icon: Icon, label }) => (
            <button
              key={key}
              onClick={() => { setPage(key); setSearch(""); }}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-all ${
                page === key ? "bg-teal-500/10 text-teal-300 border border-teal-500/20" : "text-slate-400 hover:bg-slate-800/60 hover:text-slate-200 border border-transparent"
              }`}
            >
              <Icon className="w-4 h-4" />
              {label}
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-slate-800 text-xs text-slate-500 flex items-center gap-1.5">
          <span className={`w-1.5 h-1.5 rounded-full ${socketConnected ? "bg-teal-400 animate-pulse" : "bg-slate-600"}`} />
          {socketConnected ? "Live: connected (WebSocket)" : "Live: connecting…"}
        </div>
      </aside>

      <div className="flex-1 min-w-0">
        <header className="h-16 border-b border-slate-800 flex items-center justify-between px-6 gap-4 bg-gradient-to-r from-slate-950 via-slate-900/30 to-slate-950">
          <div className="relative w-80 max-w-full">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search CVE, malware, IP, threat actor…"
              className="w-full bg-slate-900 border border-slate-800 rounded-md pl-9 pr-3 py-2 text-sm placeholder-slate-500 focus:outline-none focus:border-teal-600"
            />
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIndiaOnly((v) => !v)}
              className={`flex items-center gap-1.5 text-xs rounded-md px-2.5 py-1.5 border ${
                indiaOnly ? "border-amber-600 text-amber-300 bg-amber-500/10" : "border-slate-800 text-slate-400 hover:text-slate-200"
              }`}
            >
              <MapPin className="w-3.5 h-3.5" /> {indiaOnly ? "India only: ON" : "India only: OFF"}
            </button>
            <button onClick={runIngest} disabled={ingesting} className="flex items-center gap-1.5 text-xs text-teal-400 hover:text-teal-300 border border-teal-800 rounded-md px-2.5 py-1.5 disabled:opacity-50">
              <Zap className={`w-3.5 h-3.5 ${ingesting ? "animate-pulse" : ""}`} /> {ingesting ? "Fetching live data…" : "Run live ingestion"}
            </button>
            <button onClick={loadAll} className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200">
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} /> Refresh
            </button>
            <button className="relative">
              <Bell className="w-5 h-5 text-slate-400" />
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-[10px] flex items-center justify-center text-white">{alerts.length}</span>
            </button>
            <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-xs text-slate-300">AN</div>
          </div>
        </header>

        {ingestMsg && (
          <div className="px-6 pt-3 text-xs text-slate-400 bg-slate-900/60 border-b border-slate-800 py-2">
            <span className="text-teal-400">Ingestion result:</span> {ingestMsg}
          </div>
        )}

        <main className="p-6">
          {searchResults ? (
            <div className="space-y-4">
              <h1 className="text-lg font-medium text-slate-100">Search results for "{search}"</h1>
              <div className="bg-slate-900 border border-slate-800 rounded-lg">
                {searchResults.length === 0 && <p className="p-4 text-sm text-slate-500">No matches.</p>}
                {searchResults.map((t) => <ThreatRow key={t._id} t={t} onClick={() => setSelected(t)} />)}
              </div>
            </div>
          ) : (
            <>
              {page === "dashboard" && <DashboardPage threats={indiaOnly ? threats.filter((t) => t.isIndiaRelated) : threats} stats={stats} alerts={alerts} onSelect={setSelected} indiaOnly={indiaOnly} />}
              {page === "feed" && <FeedPage threats={indiaOnly ? threats.filter((t) => t.isIndiaRelated) : threats} onSelect={setSelected} />}
              {page === "indicators" && <IndicatorsPage indicators={indicators} />}
              {page === "mitre" && <MitrePage mitre={mitre} />}
              {page === "actors" && <ActorsPage actors={actors} />}
              {page === "alerts" && <AlertsPage alerts={alerts} />}
              {page === "pipeline" && <PipelinePage liveLog={liveLog} />}
            </>
          )}
        </main>
      </div>

      <DetailModal threat={selected} onClose={() => setSelected(null)} />

      {toast && (
        <div className="fixed top-4 right-4 z-[100] bg-red-950 border border-red-700 text-red-200 text-sm px-4 py-3 rounded-lg shadow-xl max-w-sm">
          <div className="flex items-center gap-2 font-medium mb-1">
            <ShieldAlert className="w-4 h-4" /> Critical alert — pushed live
          </div>
          <p className="text-red-300">{toast.message}</p>
          {toast.cve && toast.cve !== "—" && <p className="text-xs font-mono text-red-400 mt-1">{toast.cve}</p>}
        </div>
      )}
    </div>
  );
}
